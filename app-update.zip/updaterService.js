const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { app } = require('electron');

const REPO_OWNER = 'DALY66';
const RELEASE_REPO = 'IMPRENT-ON-LAN-RELEASE';
const SOURCE_REPO = 'IMPRENT-ON-LAN';
const VERSION_URL = `https://raw.githubusercontent.com/${REPO_OWNER}/${RELEASE_REPO}/main/version.json`;
const ZIP_URL = `https://raw.githubusercontent.com/${REPO_OWNER}/${RELEASE_REPO}/main/app-update.zip`;

let updateState = {
  checking: false,
  available: false,
  downloading: false,
  downloaded: false,
  error: null,
  currentVersion: require('./package.json').version,
  latestVersion: null,
  releaseNotes: ''
};

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const options = {
      hostname: parsed.hostname,
      path: parsed.pathname + (parsed.search || ''),
      headers: {
        'User-Agent': 'ImprentOnLAN-Updater',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      },
      timeout: 8000
    };

    const req = https.get(options, (res) => {
      // Manejar redirecciones (GitHub usa 302/301 con frecuencia)
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(fetchJson(res.headers.location));
      }

      if (res.statusCode < 200 || res.statusCode >= 300) {
        return reject(new Error(`HTTP ${res.statusCode} al consultar actualizaciones`));
      }

      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timeout al consultar GitHub'));
    });

    req.on('error', reject);
  });
}

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const client = parsed.protocol === 'https:' ? https : http;
    const options = {
      hostname: parsed.hostname,
      path: parsed.pathname + (parsed.search || ''),
      headers: {
        'User-Agent': 'ImprentOnLAN-Updater',
        'Cache-Control': 'no-cache'
      },
      timeout: 30000
    };

    const req = client.get(options, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(downloadFile(res.headers.location, destPath));
      }

      if (res.statusCode !== 200) {
        return reject(new Error(`Fallo descarga HTTP ${res.statusCode}`));
      }

      const fileStream = fs.createWriteStream(destPath);
      res.pipe(fileStream);

      fileStream.on('finish', () => {
        fileStream.close();
        resolve(destPath);
      });

      fileStream.on('error', (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timeout durante la descarga'));
    });

    req.on('error', (err) => {
      fs.unlink(destPath, () => {});
      reject(err);
    });
  });
}

function isNewerVersion(remote, local) {
  const r = remote.replace(/^v/, '').split('.').map(Number);
  const l = local.replace(/^v/, '').split('.').map(Number);
  for (let i = 0; i < Math.max(r.length, l.length); i++) {
    const rVal = r[i] || 0;
    const lVal = l[i] || 0;
    if (rVal > lVal) return true;
    if (rVal < lVal) return false;
  }
  return false;
}

async function checkForUpdates(mainWindow = null) {
  if (updateState.checking) return updateState;
  updateState.checking = true;
  updateState.error = null;

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('checking_update');
  }

  try {
    const remoteInfo = await fetchJson(VERSION_URL);
    updateState.checking = false;

    if (remoteInfo && remoteInfo.version) {
      updateState.latestVersion = remoteInfo.version;
      updateState.releaseNotes = remoteInfo.releaseNotes || '';

      const hasUpdate = isNewerVersion(remoteInfo.version, updateState.currentVersion);
      updateState.available = hasUpdate;

      if (hasUpdate) {
        console.log(`[Updater] ¡Nueva versión detectada en GitHub!: v${remoteInfo.version} (Actual: v${updateState.currentVersion})`);
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('update_available', {
            version: remoteInfo.version,
            currentVersion: updateState.currentVersion,
            releaseNotes: updateState.releaseNotes
          });
        }

        // Descargar e instalar automáticamente en segundo plano
        await autoDownloadAndApply(remoteInfo.downloadUrl || ZIP_URL, mainWindow);
      } else {
        console.log(`[Updater] Aplicación al día: v${updateState.currentVersion}`);
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('update_not_available', {
            version: updateState.currentVersion
          });
        }
      }
    }
  } catch (err) {
    updateState.checking = false;
    updateState.error = err.message;
    console.warn('[Updater] No se pudo verificar actualización en GitHub:', err.message);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('update_error', err.message);
    }
  }

  return updateState;
}

async function autoDownloadAndApply(downloadUrl, mainWindow = null) {
  try {
    updateState.downloading = true;
    const tempZip = path.join(app.getPath('temp'), `imprent_update_${Date.now()}.zip`);

    console.log('[Updater] Descargando paquete de actualización desde GitHub...');
    await downloadFile(downloadUrl, tempZip);

    console.log('[Updater] Paquete descargado con éxito. Aplicando archivos...');
    const appDir = path.resolve(__dirname);

    // Extraer silenciosamente reemplazando los archivos de código
    await new Promise((resolve, reject) => {
      const psCommand = `powershell -NoProfile -Command "Expand-Archive -Path '${tempZip}' -DestinationPath '${appDir}' -Force; Remove-Item '${tempZip}' -Force"`;
      exec(psCommand, { windowsHide: true }, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });

    updateState.downloading = false;
    updateState.downloaded = true;
    console.log('[Updater] ¡Actualización aplicada correctamente!');

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('update_downloaded', {
        version: updateState.latestVersion,
        releaseNotes: updateState.releaseNotes
      });
    }

    // Reinicio automático en 4 segundos
    setTimeout(() => {
      restartApp();
    }, 4000);
  } catch (err) {
    updateState.downloading = false;
    updateState.error = err.message;
    console.error('[Updater] Error al aplicar actualización:', err);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('update_error', err.message);
    }
  }
}

function restartApp() {
  console.log('[Updater] Reiniciando aplicación para completar actualización...');
  app.relaunch();
  app.exit(0);
}

function initUpdater(mainWindow) {
  // Comprobación inicial 3 segundos tras iniciar
  setTimeout(() => {
    checkForUpdates(mainWindow);
  }, 3000);

  // Comprobación periódica cada 1 hora
  setInterval(() => {
    checkForUpdates(mainWindow);
  }, 60 * 60 * 1000);
}

module.exports = {
  checkForUpdates,
  restartApp,
  initUpdater,
  getUpdateState: () => ({ ...updateState })
};

