const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

/**
 * Escanea y obtiene la lista de impresoras instaladas en Windows
 */
function getSystemPrinters() {
  return new Promise((resolve) => {
    const cmd = `powershell -NoProfile -Command "Get-CimInstance Win32_Printer | Select-Object Name, PortName, Default, PrinterStatus | ConvertTo-Json -Compress"`;

    exec(cmd, { timeout: 6000 }, (err, stdout, stderr) => {
      if (err || !stdout || !stdout.trim()) {
        exec('wmic printer get name,default /format:csv', (err2, stdout2) => {
          if (err2 || !stdout2) return resolve([]);
          const lines = stdout2.trim().split('\n').slice(1);
          const list = lines
            .map(l => l.trim().split(','))
            .filter(parts => parts.length >= 2 && parts[1])
            .map(parts => ({
              name: parts[2] ? parts[2].trim() : parts[1].trim(),
              isDefault: parts[1].trim().toLowerCase() === 'true',
              port: ''
            }));
          resolve(list);
        });
        return;
      }

      try {
        let parsed = JSON.parse(stdout.trim());
        if (!Array.isArray(parsed)) parsed = [parsed];
        const printers = parsed.map(p => ({
          name: p.Name,
          port: p.PortName || '',
          isDefault: Boolean(p.Default),
          status: p.PrinterStatus === 3 ? 'Listo / Conectado' : 'Disponible'
        }));
        resolve(printers);
      } catch (parseErr) {
        resolve([]);
      }
    });
  });
}

/**
 * Genera el documento HTML adaptado con precisión para rollo térmico de 58mm o 80mm
 * Totalmente personalizable (logo, campos activables/desactivables, campos extra, estilos)
 */
function generateTicketHtml(ticket, template = {}, paperWidth = '80mm') {
  const is58 = paperWidth === '58mm';
  const printableWidth = is58 ? '48mm' : '72mm';
  const fontSize = is58 ? '10.5px' : '12px';

  // Configuración de la plantilla
  const tLogo = template.logo || '';
  const showLogo = Boolean(template.showLogo && tLogo);
  const logoSize = template.logoSize || 'medium';
  let logoMaxWidth = '50mm';
  if (logoSize === 'small') logoMaxWidth = '30mm';
  if (logoSize === 'large') logoMaxWidth = is58 ? '44mm' : '65mm';

  const headerAlign = template.headerAlign || 'center';
  const sepStyle = template.separatorStyle || 'dashed';
  const currency = template.currencySymbol || '€';
  const fields = template.fields || {};
  const customFields = Array.isArray(template.customFields) ? template.customFields : [];

  // Datos de empresa
  const fBiz = fields.businessName || { enabled: true, value: '', bold: true, size: 'large' };
  const fSub = fields.subtitle || { enabled: false, value: '' };
  const fCif = fields.cif || { enabled: true, label: 'CIF/NIF:', value: '' };
  const fAddr = fields.address || { enabled: true, value: '' };
  const fPhone = fields.phone || { enabled: true, label: 'TEL:', value: '' };
  const fWeb = fields.emailOrWeb || { enabled: false, label: 'Web:', value: '' };

  // Metadatos del ticket
  const fNum = fields.ticketNumber || { enabled: true, prefix: 'TICKET #' };
  const fDate = fields.dateTime || { enabled: true };
  const fCust = fields.customer || { enabled: true, label: 'Cliente / Mesa:' };
  const fCash = fields.cashier || { enabled: true, label: 'Atendido por:' };
  const fPay = fields.paymentMethod || { enabled: true, label: 'Forma de pago:' };
  const fTax = fields.showTaxBreakdown || { enabled: true };
  const fFoot = fields.footer || { enabled: true, value: '' };
  const fLegal = fields.legalNote || { enabled: false, value: '' };
  const fEnd = fields.endNotice || { enabled: true, value: '*** Fin de ticket ***' };

  const ticketNum = (ticket.number !== undefined && ticket.number !== null && ticket.number !== '') ? String(ticket.number) : '0';
  const dateStr = ticket.date || new Date().toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' });
  const paymentMethod = ticket.paymentMethod || 'Efectivo';

  // Items
  const items = Array.isArray(ticket.items) ? ticket.items : [];
  let calculatedSubtotal = 0;
  const itemsHtml = items.map(item => {
    const qty = Number(item.qty) || 1;
    const price = Number(item.price) || 0;
    const total = Number(item.total !== undefined ? item.total : (qty * price));
    calculatedSubtotal += total;

    return `
      <tr>
        <td style="text-align: left; padding: 2px 0; vertical-align: top;">
          <strong>${qty}x</strong> ${escapeHtml(item.name)}
        </td>
        <td style="text-align: right; padding: 2px 0; white-space: nowrap; vertical-align: top;">
          ${total.toFixed(2)}${escapeHtml(currency)}
        </td>
      </tr>
    `;
  }).join('');

  const subtotal = ticket.subtotal !== undefined ? Number(ticket.subtotal) : calculatedSubtotal;
  const taxRate = ticket.taxRate !== undefined ? Number(ticket.taxRate) : (Number(fields.taxRate) || 21);
  const taxAmount = (subtotal * (taxRate / 100));
  const totalAmount = ticket.total !== undefined ? Number(ticket.total) : (subtotal + taxAmount);

  // Separador CSS
  let dividerBorder = '1px dashed #000';
  if (sepStyle === 'solid') dividerBorder = '1px solid #000';
  if (sepStyle === 'double') dividerBorder = '3px double #000';
  if (sepStyle === 'none') dividerBorder = 'none';

  // Tamaño de título de empresa
  let bizTitleSize = is58 ? '13px' : '16px';
  if (fBiz.size === 'large') bizTitleSize = is58 ? '15px' : '18px';
  if (fBiz.size === 'xlarge') bizTitleSize = is58 ? '17px' : '20px';

  // Comprobar si hay contenido de cabecera
  const hasBizName = fBiz.enabled && fBiz.value;
  const hasSub = fSub.enabled && fSub.value;
  const hasCif = fCif.enabled && fCif.value;
  const hasAddr = fAddr.enabled && fAddr.value;
  const hasPhone = fPhone.enabled && fPhone.value;
  const hasWeb = fWeb.enabled && fWeb.value;
  const hasHeaderContent = showLogo || hasBizName || hasSub || hasCif || hasAddr || hasPhone || hasWeb;

  // Campos personalizados activos
  const activeCustomFields = customFields.filter(cf => cf.enabled && (cf.label || cf.value));

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Ticket ${ticketNum}</title>
  <style>
    @page {
      margin: 0;
      size: ${paperWidth} auto;
    }
    *, *::before, *::after {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 3mm 2mm;
      width: ${printableWidth};
      font-family: 'Courier New', Courier, 'Lucida Console', monospace;
      font-size: ${fontSize};
      line-height: 1.25;
      color: #000000;
      background: #ffffff;
      -webkit-print-color-adjust: exact;
    }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .text-left { text-align: left; }
    .bold { font-weight: bold; }
    .divider {
      border-top: ${dividerBorder};
      margin: 5px 0;
    }
    .ticket-logo {
      display: block;
      margin: 0 auto 6px auto;
      max-width: ${logoMaxWidth};
      height: auto;
      filter: grayscale(100%) contrast(140%);
    }
    .biz-title {
      font-size: ${bizTitleSize};
      font-weight: ${fBiz.bold !== false ? '900' : 'normal'};
      margin-bottom: 2px;
      letter-spacing: 0.5px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 3px 0;
    }
    .totals-table td {
      padding: 1px 0;
    }
    .grand-total {
      font-size: ${is58 ? '14px' : '16px'};
      font-weight: 900;
      padding-top: 3px;
    }
    .footer-note {
      white-space: pre-line;
      margin-top: 6px;
      font-size: ${fontSize};
    }
    .legal-note {
      white-space: pre-line;
      margin-top: 4px;
      font-size: calc(${fontSize} - 1.5px);
      line-height: 1.15;
    }
    .ticket-meta {
      font-size: calc(${fontSize} - 0.5px);
      margin: 2px 0;
    }
  </style>
</head>
<body>

  ${hasHeaderContent ? `
  <div class="text-${headerAlign}">
    ${showLogo ? `<img src="${tLogo}" class="ticket-logo" alt="Logo">` : ''}
    ${hasBizName ? `<div class="biz-title">${escapeHtml(fBiz.value)}</div>` : ''}
    ${hasSub ? `<div style="font-size: calc(${fontSize} - 0.5px); font-style: italic;">${escapeHtml(fSub.value)}</div>` : ''}
    ${hasAddr ? `<div>${escapeHtml(fAddr.value)}</div>` : ''}
    ${hasCif ? `<div>${escapeHtml(fCif.label || '')} ${escapeHtml(fCif.value)}</div>` : ''}
    ${hasPhone ? `<div>${escapeHtml(fPhone.label || '')} ${escapeHtml(fPhone.value)}</div>` : ''}
    ${hasWeb ? `<div>${escapeHtml(fWeb.label || '')} ${escapeHtml(fWeb.value)}</div>` : ''}
  </div>
  <div class="divider"></div>
  ` : ''}

  <!-- Metadatos del ticket -->
  <div class="ticket-meta">
    <div style="display: flex; justify-content: space-between;">
      ${fNum.enabled ? `<span><strong>${escapeHtml(fNum.prefix || 'TICKET #')}${escapeHtml(ticketNum.replace(/^#/, ''))}</strong></span>` : '<span></span>'}
      ${fDate.enabled ? `<span>${escapeHtml(dateStr)}</span>` : ''}
    </div>
    ${fCust.enabled && ticket.customer ? `<div>${escapeHtml(fCust.label || 'Cliente:')} ${escapeHtml(ticket.customer)}</div>` : ''}
    ${fCash.enabled && ticket.cashier ? `<div>${escapeHtml(fCash.label || 'Atendido por:')} ${escapeHtml(ticket.cashier)}</div>` : ''}

    <!-- Campos personalizados extras -->
    ${activeCustomFields.map(cf => `
      <div><strong>${escapeHtml(cf.label || '')}:</strong> ${escapeHtml(cf.value || '')}</div>
    `).join('')}
  </div>

  <div class="divider"></div>

  <!-- Tabla de artículos -->
  <table>
    <thead>
      <tr style="border-bottom: 1px dashed #000;">
        <th style="text-align: left; font-size: 11px;">CONCEPTO</th>
        <th style="text-align: right; font-size: 11px; width: 50px;">TOTAL</th>
      </tr>
    </thead>
    <tbody>
      ${itemsHtml || '<tr><td colspan="2" style="text-align:center; padding: 4px 0;">(Sin artículos)</td></tr>'}
    </tbody>
  </table>

  <div class="divider"></div>

  <!-- Totales -->
  <table class="totals-table">
    ${fTax.enabled ? `
    <tr>
      <td class="text-left">Base Imponible:</td>
      <td class="text-right">${subtotal.toFixed(2)}${escapeHtml(currency)}</td>
    </tr>
    <tr>
      <td class="text-left">I.V.A. (${taxRate}%):</td>
      <td class="text-right">${taxAmount.toFixed(2)}${escapeHtml(currency)}</td>
    </tr>
    ` : ''}
    <tr class="grand-total">
      <td class="text-left bold">TOTAL:</td>
      <td class="text-right bold">${totalAmount.toFixed(2)}${escapeHtml(currency)}</td>
    </tr>
    ${fPay.enabled ? `
    <tr>
      <td class="text-left" style="font-size: 11px; padding-top: 3px;">${escapeHtml(fPay.label || 'Forma de pago:')}</td>
      <td class="text-right" style="font-size: 11px; padding-top: 3px;">${escapeHtml(paymentMethod)}</td>
    </tr>
    ` : ''}
  </table>

  ${(fFoot.enabled && fFoot.value) || (fLegal.enabled && fLegal.value) ? `
  <div class="divider"></div>
  ` : ''}

  ${fFoot.enabled && fFoot.value ? `
  <div class="text-center footer-note">
    ${escapeHtml(fFoot.value)}
  </div>
  ` : ''}

  ${fLegal.enabled && fLegal.value ? `
  <div class="text-center legal-note">
    ${escapeHtml(fLegal.value)}
  </div>
  ` : ''}

  ${fEnd.enabled && fEnd.value ? `
  <div class="text-center" style="margin-top: 8px; font-size: 10px;">
    ${escapeHtml(fEnd.value)}
  </div>
  ` : ''}

</body>
</html>`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

module.exports = {
  getSystemPrinters,
  generateTicketHtml
};
