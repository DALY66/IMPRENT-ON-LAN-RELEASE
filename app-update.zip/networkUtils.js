const os = require('os');
const dgram = require('dgram');

/**
 * Obtiene las direcciones IPv4 locales de la máquina (excluyendo 127.0.0.1 y virtuales no deseadas)
 */
function getLocalIps() {
  const nets = os.networkInterfaces();
  const results = [];

  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      // Solo IPv4 y no interna
      if (net.family === 'IPv4' && !net.internal) {
        // Filtrar direcciones APIPA (169.254.x.x) si hay otras mejores
        results.push({
          interface: name,
          ip: net.address,
          isApipa: net.address.startsWith('169.254.')
        });
      }
    }
  }

  // Ordenar para poner las IPs de red real (192.168.x.x, 10.x.x.x, 172.16-31.x.x) primero
  results.sort((a, b) => {
    if (a.isApipa && !b.isApipa) return 1;
    if (!a.isApipa && b.isApipa) return -1;
    return 0;
  });

  return results.map(r => r.ip);
}

/**
 * Inicia el servicio UDP en el PC Principal para auto-descubrimiento en la red local
 */
function startDiscoveryServer(discoveryPort = 8990, getInfoCallback) {
  let server = null;
  let broadcastInterval = null;

  try {
    server = dgram.createSocket({ type: 'udp4', reuseAddr: true });

    server.on('error', (err) => {
      console.warn('Aviso en socket UDP de auto-descubrimiento:', err.message);
    });

    server.on('message', (msg, rinfo) => {
      const text = msg.toString().trim();
      if (text === 'TICKET_PRINT_DISCOVER') {
        const info = getInfoCallback ? getInfoCallback() : {};
        const responseData = JSON.stringify({
          type: 'TICKET_PRINT_SERVER',
          ...info
        });
        const responseBuffer = Buffer.from(responseData);
        server.send(responseBuffer, 0, responseBuffer.length, rinfo.port, rinfo.address, (err) => {
          if (err) console.error('Error enviando respuesta UDP:', err);
        });
      }
    });

    server.bind(discoveryPort, () => {
      try {
        server.setBroadcast(true);
      } catch (e) {
        // Ignorar si no soporta broadcast directo en bind
      }
      console.log(`[Auto-descubrimiento] Servidor UDP a la escucha en puerto ${discoveryPort}`);
    });

    // Baliza de anuncio cada 5 segundos
    broadcastInterval = setInterval(() => {
      if (!server) return;
      try {
        const info = getInfoCallback ? getInfoCallback() : {};
        const announcement = JSON.stringify({
          type: 'TICKET_PRINT_BEACON',
          ...info
        });
        const msg = Buffer.from(announcement);
        server.send(msg, 0, msg.length, discoveryPort, '255.255.255.255');
      } catch (e) {
        // En algunas redes el broadcast falla si no hay interfaz activa
      }
    }, 5000);

  } catch (err) {
    console.warn('No se pudo iniciar el servicio de auto-descubrimiento UDP:', err.message);
  }

  return {
    stop: () => {
      if (broadcastInterval) clearInterval(broadcastInterval);
      if (server) {
        try { server.close(); } catch (e) {}
      }
    }
  };
}

/**
 * Busca el PC Principal en la red local mediante un ping UDP broadcast
 */
function discoverPrincipal(discoveryPort = 8990, timeoutMs = 2500) {
  return new Promise((resolve) => {
    let client = null;
    let timer = null;
    let finished = false;

    try {
      client = dgram.createSocket({ type: 'udp4', reuseAddr: true });

      client.on('message', (msg, rinfo) => {
        try {
          const data = JSON.parse(msg.toString());
          if (data.type === 'TICKET_PRINT_SERVER' || data.type === 'TICKET_PRINT_BEACON') {
            if (!finished) {
              finished = true;
              clearTimeout(timer);
              try { client.close(); } catch (e) {}
              resolve({
                found: true,
                ip: data.ip || rinfo.address,
                port: data.port || 8989,
                name: data.name || 'PC Principal',
                printer: data.printer || 'No seleccionada'
              });
            }
          }
        } catch (e) {
          // Ignorar paquetes que no sean JSON válido
        }
      });

      client.bind(0, () => {
        try {
          client.setBroadcast(true);
          const message = Buffer.from('TICKET_PRINT_DISCOVER');
          client.send(message, 0, message.length, discoveryPort, '255.255.255.255');
        } catch (e) {
          console.warn('Error enviando broadcast de descubrimiento:', e.message);
        }
      });

      timer = setTimeout(() => {
        if (!finished) {
          finished = true;
          try { client.close(); } catch (e) {}
          resolve({ found: false, error: 'No se detectó ningún PC Principal en la red local en el tiempo límite.' });
        }
      }, timeoutMs);

    } catch (err) {
      if (!finished) {
        finished = true;
        resolve({ found: false, error: err.message });
      }
    }
  });
}

module.exports = {
  getLocalIps,
  startDiscoveryServer,
  discoverPrincipal
};

