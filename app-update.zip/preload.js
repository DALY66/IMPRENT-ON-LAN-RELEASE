const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getConfig: () => ipcRenderer.invoke('get-config'),
  saveConfig: (newConfig) => ipcRenderer.invoke('save-config', newConfig),
  getPrinters: () => ipcRenderer.invoke('get-printers'),
  getLocalIps: () => ipcRenderer.invoke('get-local-ips'),
  discoverPrincipal: () => ipcRenderer.invoke('discover-principal'),
  printTicketLocal: (data) => ipcRenderer.invoke('print-ticket-local', data),
  getLicenseStatus: () => ipcRenderer.invoke('get-license-status'),
  checkLicense: () => ipcRenderer.invoke('check-license'),
  emergencyUnlock: (pin) => ipcRenderer.invoke('emergency-unlock', pin),
  getHistory: () => ipcRenderer.invoke('get-history'),
  clearHistory: () => ipcRenderer.invoke('clear-history'),
  broadcastTemplate: (data) => ipcRenderer.invoke('broadcast-template', data),
  onLicenseStatusChanged: (callback) => {
    ipcRenderer.on('license-status-changed', (event, value) => callback(value));
  },
  onServerEvent: (callback) => {
    ipcRenderer.on('server-event', (event, value) => callback(value));
  },
  checkForUpdates: () => ipcRenderer.send('check_for_updates'),
  restartApp: () => ipcRenderer.send('restart_app'),
  getUpdateState: () => ipcRenderer.invoke('get-update-state'),
  onUpdateEvent: (channel, callback) => {
    ipcRenderer.on(channel, (event, value) => callback(value));
  }
});

