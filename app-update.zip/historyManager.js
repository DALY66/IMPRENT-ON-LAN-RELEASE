const fs = require('fs');
const path = require('path');

const HISTORY_PATH = path.join(__dirname, 'history.json');
const MAX_HISTORY = 300;

function loadHistoryFile() {
  try {
    if (fs.existsSync(HISTORY_PATH)) {
      const data = fs.readFileSync(HISTORY_PATH, 'utf8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error al leer history.json:', err.message);
  }
  return [];
}

function saveHistoryFile(list) {
  try {
    fs.writeFileSync(HISTORY_PATH, JSON.stringify(list, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error al guardar history.json:', err.message);
    return false;
  }
}

let historyCache = loadHistoryFile();

function getHistory(limit = 100) {
  return historyCache.slice(0, limit);
}

function addEntry(entry) {
  if (!entry) return;
  const fullEntry = {
    id: entry.id || Date.now().toString(),
    ticketNumber: entry.ticketNumber || '0',
    date: entry.date || new Date().toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }),
    customer: entry.customer || 'Mostrador',
    total: entry.total !== undefined ? (typeof entry.total === 'number' ? entry.total.toFixed(2) + '€' : entry.total) : '0.00€',
    origin: entry.origin || 'Local (Este PC)',
    printer: entry.printer || 'Impresora Predeterminada',
    status: entry.status || 'Impreso con éxito',
    ticketData: entry.ticketData || null
  };

  historyCache.unshift(fullEntry);
  if (historyCache.length > MAX_HISTORY) {
    historyCache = historyCache.slice(0, MAX_HISTORY);
  }

  saveHistoryFile(historyCache);
  return fullEntry;
}

function clearHistory() {
  historyCache = [];
  saveHistoryFile(historyCache);
  return { success: true };
}

module.exports = {
  getHistory,
  addEntry,
  clearHistory
};

