const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const path = require('path');
const configManager = require('./configManager');
const printerService = require('./printerService');
const networkUtils = require('./networkUtils');
const licenseManager = require('./licenseManager');
const historyManager = require('./historyManager');

let serverInstance = null;
let wssInstance = null;
let udpDiscoveryInstance = null;
let printHandlerCallback = null;

function registerPrintHandler(handler) {
  printHandlerCallback = handler;
}

function startServer(port = 8989) {
  if (serverInstance) {
    return { app: serverInstance.app, server: serverInstance.server, port };
  }

  const app = express();
  app.use(cors());
  app.use(express.json());
  app.use(express.static(path.join(__dirname, 'public')));

  const server = http.createServer(app);
  const wss = new WebSocket.Server({ server });
  wssInstance = wss;

  function broadcast(event, data) {
    const payload = JSON.stringify({ event, data, timestamp: new Date().toISOString() });
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    });
  }

  // Escuchar cambios de licencia en tiempo real para emitirlos a los clientes conectados
  licenseManager.addListener((status) => {
    broadcast('license_updated', status);
  });

  wss.on('connection', (ws, req) => {
    const clientIp = req.socket.remoteAddress;
    const config = configManager.loadConfig();
    ws.send(JSON.stringify({
      event: 'welcome',
      data: {
        message: 'Conectado al PC Principal de Impresión',
        clientIp,
        ticketTemplate: config.ticketTemplate || null,
        paperWidth: config.paperWidth || '80mm',
        license: licenseManager.getStatus()
      }
    }));
  });

  // API REST

  // Enviar configuración y diseño a todos los clientes conectados de la red
  app.post('/api/sync-to-clients', (req, res) => {
    const config = configManager.loadConfig();
    const templateToSync = req.body?.ticketTemplate || config.ticketTemplate;
    const appThemeToSync = req.body?.appTheme || config.appTheme;

    // Guardar en servidor
    if (req.body?.ticketTemplate) config.ticketTemplate = req.body.ticketTemplate;
    if (req.body?.appTheme) config.appTheme = req.body.appTheme;
    configManager.saveConfig(config);

    // Emitir a todos los secundarios por WebSocket
    broadcast('template_synced', {
      ticketTemplate: templateToSync,
      appTheme: appThemeToSync,
      paperWidth: config.paperWidth,
      syncedAt: new Date().toLocaleTimeString('es-ES')
    });

    res.json({
      success: true,
      message: `Configuración y diseño enviados con éxito a ${wss.clients.size} dispositivo(s) en la red`,
      clientsCount: wss.clients.size
    });
  });

  // Obtener plantilla actual para sincronización manual
  app.get('/api/sync-template', (req, res) => {
    const config = configManager.loadConfig();
    res.json({
      ticketTemplate: config.ticketTemplate || null,
      appTheme: config.appTheme || null,
      paperWidth: config.paperWidth || '80mm'
    });
  });

  // 1. Estado del servidor
  app.get('/api/status', (req, res) => {
    const config = configManager.loadConfig();
    const localIps = networkUtils.getLocalIps();
    res.json({
      status: 'online',
      mode: config.mode,
      serverPort: config.serverPort || port,
      localIps,
      primaryIp: localIps[0] || '127.0.0.1',
      selectedPrinter: config.selectedPrinter || '(Ninguna seleccionada)',
      paperWidth: config.paperWidth || '80mm',
      connectedClients: wss.clients.size,
      business: config.business || {},
      license: licenseManager.getStatus()
    });
  });

  // 1b. Endpoints de control de licencia y bloqueo remoto
  app.get('/api/license', (req, res) => {
    res.json(licenseManager.getStatus());
  });

  app.post('/api/license/check', async (req, res) => {
    const status = await licenseManager.checkLicense();
    res.json(status);
  });

  app.post('/api/license/emergency-unlock', async (req, res) => {
    const pin = req.body?.pin;
    const result = await licenseManager.verifyEmergencyPin(pin);
    res.json(result);
  });

  // 2. Escáner de impresoras de Windows
  app.get('/api/printers', async (req, res) => {
    try {
      const printers = await printerService.getSystemPrinters();
      const config = configManager.loadConfig();
      res.json({
        printers,
        selectedPrinter: config.selectedPrinter || ''
      });
    } catch (err) {
      res.status(500).json({ error: 'Error al escanear impresoras: ' + err.message });
    }
  });

  // 3. Obtener configuración
  app.get('/api/config', (req, res) => {
    res.json(configManager.loadConfig());
  });

  // 4. Guardar configuración
  app.post('/api/config', (req, res) => {
    const current = configManager.loadConfig();
    const updated = { ...current, ...req.body };
    const saved = configManager.saveConfig(updated);
    if (saved.success) {
      broadcast('config_updated', updated);
      res.json({ success: true, config: updated });
    } else {
      res.status(500).json({ success: false, error: saved.error });
    }
  });

  // 5. Historial de tickets
  app.get('/api/history', (req, res) => {
    res.json(historyManager.getHistory(100));
  });

  // 6. Recibir e imprimir ticket (Lanzado por PC Secundario o local)
  app.post('/api/print', async (req, res) => {
    const license = licenseManager.getStatus();
    if (license.isBlocked && !license.emergencyUnlocked) {
      return res.status(403).json({
        success: false,
        error: `Acceso suspendido: ${license.blockReason || 'Cuota mensual pendiente de pago. Contacte con PRRDev.'}`
      });
    }

    const config = configManager.loadConfig();
    const { ticket, templateOverride, businessOverride, paperWidthOverride } = req.body;

    if (!ticket) {
      return res.status(400).json({ success: false, error: 'Faltan los datos del ticket' });
    }

    const template = templateOverride || config.ticketTemplate || { fields: { businessName: { value: businessOverride?.name || '' } } };
    const paperWidth = paperWidthOverride || config.paperWidth || '80mm';
    const printerName = config.selectedPrinter;

    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'Local';
    const ticketNumber = ticket.number !== undefined ? String(ticket.number) : '0';
    ticket.number = ticketNumber;

    const copies = Math.min(Math.max(parseInt(req.body.copies) || 1, 1), 5);

    const logEntry = {
      id: Date.now().toString(),
      ticketNumber,
      date: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      origin: clientIp.replace('::ffff:', ''),
      total: ticket.total !== undefined ? (typeof ticket.total === 'number' ? ticket.total.toFixed(2) + '€' : ticket.total) : '0.00€',
      customer: ticket.customer || 'Mostrador',
      printer: printerName || 'No configurada',
      status: 'Procesando',
      ticketData: ticket
    };

    broadcast('ticket_received', logEntry);

    // Si no hay impresora seleccionada
    if (!printerName) {
      logEntry.status = 'Error: Sin impresora seleccionada en PC Principal';
      historyManager.addEntry(logEntry);
      broadcast('ticket_printed', logEntry);
      return res.status(400).json({
        success: false,
        error: 'El PC Principal no tiene ninguna impresora seleccionada en sus ajustes.'
      });
    }

    // Generar HTML del ticket térmico personalizable
    const ticketHtml = printerService.generateTicketHtml(ticket, template, paperWidth);

    try {
      if (printHandlerCallback) {
        // Enviar a la función de impresión nativa (tantas copias como se solicite)
        for (let c = 0; c < copies; c++) {
          await printHandlerCallback({
            html: ticketHtml,
            printerName,
            paperWidth
          });
        }
      } else {
        console.log(`[Impresión] Procesando ticket ${ticketNumber} en impresora ${printerName}... (${copies} copias)`);
      }

      logEntry.status = 'Impreso con éxito';
      historyManager.addEntry(logEntry);
      broadcast('ticket_printed', logEntry);

      return res.json({
        success: true,
        message: `Ticket ${ticketNumber} impreso con éxito en "${printerName}"`,
        ticketNumber
      });
    } catch (err) {
      console.error('Error al imprimir ticket:', err);
      logEntry.status = 'Error: ' + err.message;
      historyManager.addEntry(logEntry);
      broadcast('ticket_printed', logEntry);

      return res.status(500).json({
        success: false,
        error: 'Error al enviar a la impresora: ' + err.message
      });
    }
  });

  // 7. Imprimir ticket de prueba
  app.post('/api/test-print', async (req, res) => {
    const config = configManager.loadConfig();
    const testTicket = {
      number: 'PRUEBA-' + Math.floor(100 + Math.random() * 900),
      date: new Date().toLocaleString('es-ES'),
      customer: 'Diagnóstico de Red',
      cashier: 'Sistema LAN',
      paymentMethod: 'Prueba',
      items: [
        { qty: 1, name: 'Conexión PC Principal', price: 0.00, total: 0.00 },
        { qty: 1, name: 'Servicio Impresión Activo', price: 0.00, total: 0.00 },
        { qty: 1, name: `Ancho configurado: ${config.paperWidth || '80mm'}`, price: 0.00, total: 0.00 }
      ],
      subtotal: 0.00,
      taxRate: 0,
      total: 0.00
    };

    req.body = { ticket: testTicket };
    return app._router.handle(req, res);
  });

  // 8. Descubrimiento de PC Principal en LAN (vía API para clientes web)
  app.get('/api/discover-principal', async (req, res) => {
    const result = await networkUtils.discoverPrincipal(8990, 2000);
    res.json(result);
  });

  server.listen(port, '0.0.0.0', () => {
    console.log(`[Servidor de Impresión] Activo en http://0.0.0.0:${port}`);
    // Iniciar auto-descubrimiento UDP para que los secundarios lo encuentren
    udpDiscoveryInstance = networkUtils.startDiscoveryServer(8990, () => {
      const cfg = configManager.loadConfig();
      const ips = networkUtils.getLocalIps();
      return {
        ip: ips[0] || '127.0.0.1',
        port,
        name: 'PC Principal (' + (cfg.business?.name || 'Impresión') + ')',
        printer: cfg.selectedPrinter || ''
      };
    });
  });

  serverInstance = { app, server, port };
  return serverInstance;
}

function stopServer() {
  if (udpDiscoveryInstance) {
    udpDiscoveryInstance.stop();
    udpDiscoveryInstance = null;
  }
  if (wssInstance) {
    wssInstance.close();
    wssInstance = null;
  }
  if (serverInstance) {
    serverInstance.server.close();
    serverInstance = null;
    console.log('[Servidor de Impresión] Detenido.');
  }
}

function broadcastToClients(event, data) {
  if (wssInstance) {
    const payload = JSON.stringify({ event, data, timestamp: new Date().toISOString() });
    let count = 0;
    wssInstance.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
        count++;
      }
    });
    return count;
  }
  return 0;
}

module.exports = {
  startServer,
  stopServer,
  registerPrintHandler,
  broadcastToClients
};

