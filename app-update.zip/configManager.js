const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const DEFAULT_CONFIG_PATH = path.join(__dirname, 'config.default.json');

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const data = fs.readFileSync(CONFIG_PATH, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error al leer config.json, usando valores por defecto:', err);
  }

  // Si no existe, cargar default y guardarlo
  try {
    const defaultData = fs.readFileSync(DEFAULT_CONFIG_PATH, 'utf8');
    const parsed = JSON.parse(defaultData);
    saveConfig(parsed);
    return parsed;
  } catch (err) {
    console.error('Error al cargar config por defecto:', err);
    return {
      mode: 'secundario',
      serverPort: 8989,
      discoveryPort: 8990,
      principalIp: '',
      selectedPrinter: '',
      paperWidth: '80mm',
      business: {
        name: 'MI COMERCIO',
        cif: '',
        phone: '',
        address: '',
        footer: '¡Gracias por su visita!',
        taxRate: 21
      }
    };
  }
}

function saveConfig(newConfig) {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(newConfig, null, 2), 'utf8');
    return { success: true };
  } catch (err) {
    console.error('Error guardando config.json:', err);
    return { success: false, error: err.message };
  }
}

module.exports = {
  loadConfig,
  saveConfig
};

