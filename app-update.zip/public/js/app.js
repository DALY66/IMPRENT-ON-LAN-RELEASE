// Estado global de la aplicación
const state = {
  isElectron: Boolean(window.electronAPI),
  config: {
    mode: 'secundario',
    serverPort: 8989,
    principalIp: '',
    selectedPrinter: '',
    paperWidth: '80mm',
    ticketTemplate: {
      logo: '',
      logoSize: 'medium',
      showLogo: false,
      headerAlign: 'center',
      separatorStyle: 'dashed',
      currencySymbol: '€',
      fields: {
        businessName: { enabled: true, value: '', bold: true, size: 'large' },
        subtitle: { enabled: false, value: '' },
        cif: { enabled: true, label: 'CIF/NIF:', value: '' },
        address: { enabled: true, value: '' },
        phone: { enabled: true, label: 'TEL:', value: '' },
        emailOrWeb: { enabled: false, label: 'Web:', value: '' },
        ticketNumber: { enabled: true, prefix: 'TICKET #' },
        dateTime: { enabled: true },
        customer: { enabled: true, label: 'Cliente / Mesa:' },
        cashier: { enabled: true, label: 'Atendido por:' },
        paymentMethod: { enabled: true, label: 'Forma de pago:' },
        showTaxBreakdown: { enabled: true },
        taxRate: 21,
        footer: { enabled: true, value: '' },
        legalNote: { enabled: false, value: '' },
        endNotice: { enabled: true, value: '*** Fin de ticket ***' }
      },
      customFields: []
    }
  },
  ticket: {
    number: '',
    customer: '',
    cashier: '',
    paymentMethod: 'Efectivo',
    taxRate: 21,
    items: []
  },
  license: {
    isBlocked: false,
    isFakeOffline: false,
    blockTitle: 'ACCESO TEMPORALMENTE SUSPENDIDO',
    blockReason: 'Cuota mensual pendiente de pago. Contacte con PRRDev para reactivar el servicio.',
    broadcastNotice: null,
    emergencyUnlocked: false,
    online: true
  },
  ws: null,
  isConnected: false
};

let soundEnabled = localStorage.getItem('ticketprint_sound') !== 'false';
let currentWizardStep = 1;
const wizardData = {
  bizName: '',
  theme: 'dark',
  font: 'modern',
  animations: true,
  role: 'secundario',
  paperWidth: '80mm',
  logo: '',
  footer: ''
};

// Inicialización al cargar la página
document.addEventListener('DOMContentLoaded', async () => {
  setupTabs();
  initTheme();
  initSplashScreen();
  initOperator();
  initUpdaterUI();
  updateSoundUI();
  await loadConfig();
  renderItemsTable();
  updatePreview();
  renderSyncBanner();
  await scanPrinters();

  if (state.config.mode === 'principal') {
    await updatePrincipalUI();
  } else {
    initSecondaryConnection();
  }

  // Inicializar contador secuencial de tickets (empieza en 0 hasta el infinito)
  initTicketCounter();
  initBillingStats();
  updatePreview();

  // Escuchar inputs del POS
  document.getElementById('ticketCustomer')?.addEventListener('input', (e) => {
    state.ticket.customer = e.target.value;
    updatePreview();
  });
  document.getElementById('ticketCashier')?.addEventListener('input', (e) => {
    state.ticket.cashier = e.target.value;
    updatePreview();
  });

  // Escuchar cambios en vivo del nombre de negocio para actualizar la cabecera al instante
  document.getElementById('tplBizNameValue')?.addEventListener('input', (e) => {
    updateTopbarBrand(e.target.value);
  });
  document.getElementById('wizBizName')?.addEventListener('input', (e) => {
    updateTopbarBrand(e.target.value, wizardData?.logo);
  });

  // Atajos de teclado rápidos
  setupKeyboardShortcuts();

  // Si es la primera vez que se abre la app, abrir el Asistente Interactivo de Configuración
  const hasOnboarded = localStorage.getItem('ticketprint_onboarded');
  if (!hasOnboarded) {
    const appShell = document.getElementById('appShell');
    if (appShell) appShell.style.display = 'none';
    openOnboardingWizard();
  } else {
    const appShell = document.getElementById('appShell');
    if (appShell) appShell.style.display = 'flex';
  }

  // Verificación de Licencia y Bloqueo Remoto (MAINWEB Cloud)
  if (window.electronAPI?.onLicenseStatusChanged) {
    window.electronAPI.onLicenseStatusChanged((lic) => {
      applyLicenseStatus(lic);
    });
  }

  // Detectar desconexión de Wi-Fi o cable inmediatamente
  window.addEventListener('offline', () => {
    applyLicenseStatus({
      isBlocked: true,
      online: false,
      blockTitle: 'SIN CONEXIÓN A INTERNET',
      blockReason: 'Se ha detectado desconexión de red (Wi-Fi o cable desconectado). Para evitar el uso no autorizado sin abono de cuota, Imprent on LAN requiere conexión activa a Internet para verificar su licencia con PRRDev.'
    });
  });

  window.addEventListener('online', () => {
    checkRemoteLicense();
  });

  checkRemoteLicense();
  setInterval(checkRemoteLicense, 2500); // Verificación continua e instantánea cada 2.5 segundos
});

// ATAJOS DE TECLADO GLOBALES
function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Ctrl + Enter o F9 para imprimir ticket directamente
    if ((e.ctrlKey && e.key === 'Enter') || e.key === 'F9') {
      e.preventDefault();
      if (state.license.isBlocked && !state.license.emergencyUnlocked) {
        showToast('Terminal bloqueada por administración.', 'error');
        return;
      }
      printCurrentTicket();
    }
  });

  // Enter en el precio para añadir artículo
  const priceInput = document.getElementById('newItemPrice');
  const nameInput = document.getElementById('newItemName');
  if (priceInput) {
    priceInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        addItemFromInputs();
      }
    });
  }
  if (nameInput) {
    nameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        priceInput.focus();
      }
    });
  }
}

// PANTALLA DE CARGA PROFESIONAL (SPLASH SCREEN)
function initSplashScreen() {
  const splash = document.getElementById('appSplashScreen');
  const fill = document.getElementById('splashProgressFill');
  const status = document.getElementById('splashStatusText');
  const percent = document.getElementById('splashPercentText');
  if (!splash) return;

  const steps = [
    { p: 25, text: 'Iniciando servicios y motor de red local...' },
    { p: 55, text: 'Verificando licencia y conectividad...' },
    { p: 85, text: 'Detectando impresoras del sistema...' },
    { p: 100, text: '¡Sistema listo!' }
  ];

  let idx = 0;
  const interval = setInterval(() => {
    if (idx < steps.length) {
      if (fill) fill.style.width = steps[idx].p + '%';
      if (status) status.textContent = steps[idx].text;
      if (percent) percent.textContent = steps[idx].p + '%';
      idx++;
    } else {
      clearInterval(interval);
      setTimeout(() => {
        splash.classList.add('fade-out');
        setTimeout(() => {
          splash.remove();
          // Si es la primera vez que se abre la app, abrir el asistente interactivo
          const hasOnboarded = localStorage.getItem('ticketprint_onboarded');
          if (!hasOnboarded) {
            const appShell = document.getElementById('appShell');
            if (appShell) appShell.style.display = 'none';
            openOnboardingWizard();
          }
        }, 500);
      }, 350);
    }
  }, 250);
}

// ASISTENTE DE BIENVENIDA / ONBOARDING ENCUESTA INICIAL
function openOnboardingWizard() {
  currentWizardStep = 1;
  const modal = document.getElementById('onboardingModal');
  if (!modal) return;

  // Cargar datos actuales en el asistente (por defecto vacíos para que el cliente rellene)
  const tpl = state.config.ticketTemplate?.fields || {};
  const currentBiz = tpl.businessName?.value || '';
  const bizInput = document.getElementById('wizBizName');
  if (bizInput) bizInput.value = currentBiz;
  wizardData.bizName = currentBiz;

  const currentFooter = tpl.footer?.value || '';
  const footerInput = document.getElementById('wizFooter');
  if (footerInput) footerInput.value = currentFooter;
  wizardData.footer = currentFooter;

  // Rol actual
  selectWizardRole(state.config.mode || 'secundario');

  // Tema actual (por defecto Dark Obsidian de alto contraste)
  const currentTheme = localStorage.getItem('ticketprint_theme') || 'dark';
  selectWizardTheme(currentTheme);

  // Fuente actual
  const currentFont = localStorage.getItem('ticketprint_font') || 'modern';
  selectWizardFont(currentFont);

  // Animaciones actuales
  const currentAnim = localStorage.getItem('ticketprint_animations') !== 'false';
  selectWizardAnimations(currentAnim);

  // Logo actual (si no tiene, dejar vacío)
  if (state.config.ticketTemplate?.logo) {
    wizardData.logo = state.config.ticketTemplate.logo;
    renderWizardLogoThumb(wizardData.logo, 'Logotipo activo');
  } else {
    wizardData.logo = '';
    removeWizardLogo();
  }

  // Mostrar botón de cerrar solo si ya se ha completado el asistente al menos una vez
  const hasOnboarded = localStorage.getItem('ticketprint_onboarded');
  const btnClose = document.getElementById('btnWizClose');
  if (btnClose) {
    btnClose.style.display = hasOnboarded ? 'inline-flex' : 'none';
  }

  showWizardStep(1);
  modal.style.display = 'flex';
}

function closeOnboardingWizard() {
  const modal = document.getElementById('onboardingModal');
  if (modal) modal.style.display = 'none';
  const appShell = document.getElementById('appShell');
  if (appShell) appShell.style.display = 'flex';
}

function removeWizardLogo() {
  wizardData.logo = '';
  const thumb = document.getElementById('wizLogoThumb');
  if (thumb) thumb.innerHTML = '<span style="font-size: 11px; color: #64748b;">Sin logo</span>';
  const status = document.getElementById('wizLogoStatusText');
  if (status) status.innerHTML = '<span style="color: #94a3b8;">Ningún logotipo seleccionado</span>';
  const btnRemove = document.getElementById('btnWizRemoveLogo');
  if (btnRemove) btnRemove.style.display = 'none';
  if (typeof updateTopbarBrand === 'function') {
    updateTopbarBrand(document.getElementById('wizBizName')?.value || null, '');
  }
}

function renderWizardLogoThumb(base64Src, statusMsg) {
  const thumb = document.getElementById('wizLogoThumb');
  if (thumb) {
    thumb.innerHTML = `<img src="${base64Src}" style="max-width: 100%; max-height: 100%; object-fit: contain; filter: grayscale(100%) contrast(140%);">`;
  }
  const status = document.getElementById('wizLogoStatusText');
  if (status) {
    status.innerHTML = `<span style="color: #10b981; font-weight: 700;">✅ ${escapeHtml(statusMsg)}</span>`;
  }
  const btnRemove = document.getElementById('btnWizRemoveLogo');
  if (btnRemove) btnRemove.style.display = 'inline-block';
}

function handleWizardLogo(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    wizardData.logo = e.target.result;
    renderWizardLogoThumb(wizardData.logo, file.name);
    if (typeof updateTopbarBrand === 'function') {
      updateTopbarBrand(document.getElementById('wizBizName')?.value || null, wizardData.logo);
    }
    showToast('Logotipo cargado correctamente', 'success');
  };
  reader.readAsDataURL(file);
}

function showWizardStep(step) {
  currentWizardStep = step;

  const titles = [
    '1. Identidad del Negocio y Logotipo del Ticket',
    '2. Colores y Tema de la Aplicación',
    '3. Tipografía del Programa (Fuente)',
    '4. Animaciones del Programa',
    '5. Rol de este Equipo en la Red Local',
    '6. ¡Todo Listo para Empezar!'
  ];

  const descriptions = [
    'Configura el nombre comercial y el logotipo que aparecerá impreso en la cabecera de tus tickets.',
    'Elige el esquema de color que más te guste para trabajar. Cambia en tiempo real con un clic.',
    'Selecciona el estilo de letra para los textos, menús y botones del programa.',
    'Elige entre una interfaz con animaciones fluidas o el modo ultrarrápido instantáneo.',
    'Indica si este equipo es el que tiene la impresora física conectada o es una caja secundaria.',
    'Revisa tu configuración y pulsa el botón para guardar y acceder directamente a la aplicación.'
  ];

  const badgeEl = document.getElementById('wizStepBadge');
  if (badgeEl) badgeEl.textContent = `PASO ${step} DE 6`;

  const titleEl = document.getElementById('wizStepTitle');
  if (titleEl) titleEl.textContent = titles[step - 1];

  const descEl = document.getElementById('wizStepDesc');
  if (descEl) descEl.textContent = descriptions[step - 1];

  // Actualizar indicadores de progreso y paneles
  for (let i = 1; i <= 6; i++) {
    const ind = document.getElementById(`stepInd-${i}`);
    const pane = document.getElementById(`wizStep-${i}`);
    if (ind) {
      ind.className = 'step-indicator';
      if (i === step) ind.classList.add('active');
      if (i < step) ind.classList.add('completed');
    }
    if (pane) {
      pane.className = 'step-pane';
      if (i === step) pane.classList.add('active');
    }
  }

  // Botones anterior / siguiente
  const btnPrev = document.getElementById('btnWizPrev');
  const btnNext = document.getElementById('btnWizNext');
  const btnFinish = document.getElementById('btnWizFinish');

  if (btnPrev) btnPrev.style.display = step > 1 ? 'inline-flex' : 'none';
  if (btnNext) btnNext.style.display = step < 6 ? 'inline-flex' : 'none';
  if (btnFinish) btnFinish.style.display = step === 6 ? 'inline-flex' : 'none';

  // Si llegamos al paso 6, actualizar el resumen
  if (step === 6) {
    const bName = document.getElementById('wizBizName')?.value.trim() || 'Mi Negocio (Sin especificar)';
    const sumBiz = document.getElementById('wizSummaryBiz');
    if (sumBiz) sumBiz.textContent = bName;

    const sumLogo = document.getElementById('wizSummaryLogo');
    if (sumLogo) {
      sumLogo.innerHTML = wizardData.logo
        ? `<span style="color: #10b981; font-weight: 700;">✅ Logotipo activo</span>`
        : '<span style="color: #94a3b8;">Sin logotipo</span>';
    }

    const sumTheme = document.getElementById('wizSummaryTheme');
    if (sumTheme) sumTheme.textContent = getThemeLabel(wizardData.theme);

    const sumFont = document.getElementById('wizSummaryFont');
    if (sumFont) sumFont.textContent = getFontLabel(wizardData.font);

    const sumAnim = document.getElementById('wizSummaryAnim');
    if (sumAnim) sumAnim.textContent = wizardData.animations ? '✨ Fluidas Activadas' : '⚡ Desactivadas (Ultrarrápido)';

    const sumRole = document.getElementById('wizSummaryRole');
    if (sumRole) sumRole.textContent = wizardData.role === 'principal' ? '👑 PC Principal (Con Impresora)' : '💻 PC Secundario (Puesto Emisor)';
  }
}

function nextWizardStep() {
  if (currentWizardStep === 1) {
    wizardData.bizName = document.getElementById('wizBizName')?.value.trim() || '';
    wizardData.footer = document.getElementById('wizFooter')?.value.trim() || '';
  }
  if (currentWizardStep < 6) {
    showWizardStep(currentWizardStep + 1);
  }
}

function prevWizardStep() {
  if (currentWizardStep > 1) {
    showWizardStep(currentWizardStep - 1);
  }
}

function selectWizardRole(role) {
  wizardData.role = role;
  const cardSec = document.getElementById('wizRoleCardSec');
  const cardPrin = document.getElementById('wizRoleCardPrin');
  const radSec = document.getElementById('wizRadioSec');
  const radPrin = document.getElementById('wizRadioPrin');
  const secIpSection = document.getElementById('wizSecondaryIpSection');

  if (role === 'principal') {
    cardPrin?.classList.add('selected');
    cardSec?.classList.remove('selected');
    if (radPrin) radPrin.checked = true;
    if (secIpSection) secIpSection.style.display = 'none';
  } else {
    cardSec?.classList.add('selected');
    cardPrin?.classList.remove('selected');
    if (radSec) radSec.checked = true;
    if (secIpSection) secIpSection.style.display = 'block';
  }
}

async function wizAutoDiscover() {
  const statusEl = document.getElementById('wizIpStatus');
  const ipInput = document.getElementById('wizPrincipalIp');
  if (statusEl) statusEl.innerHTML = '<span style="color: var(--primary);">🔍 Buscando PC Principal en la red local...</span>';

  try {
    let result = null;
    if (state.isElectron && window.electronAPI?.discoverPrincipal) {
      result = await window.electronAPI.discoverPrincipal();
    } else {
      const res = await fetch('/api/discover-principal');
      if (res.ok) result = await res.json();
    }

    if (result && result.found && result.ip) {
      if (ipInput) ipInput.value = result.ip;
      if (statusEl) statusEl.innerHTML = `<span style="color: var(--success); font-weight: bold;">✅ Detectado PC Principal en ${result.ip}</span>`;
      showToast(`PC Principal detectado en ${result.ip}`, 'success');
      syncFromPrincipal(result.ip, result.port || 8989, true);
    } else {
      if (statusEl) statusEl.innerHTML = '<span style="color: #f59e0b;">⚠️ No se detectó automáticamente. Escribe la IP manualmente.</span>';
    }
  } catch (err) {
    if (statusEl) statusEl.innerHTML = `<span style="color: var(--danger);">Error: ${err.message}</span>`;
  }
}

function selectWizardTheme(theme) {
  wizardData.theme = theme;
  document.querySelectorAll('.theme-card-option').forEach(c => c.classList.remove('selected'));
  const card = document.getElementById(`wizTheme-${theme}`);
  if (card) card.classList.add('selected');

  // Aplicar tema en tiempo real para que el usuario vea cómo queda
  setAppTheme(theme, true);
}

function selectWizardFont(font) {
  wizardData.font = font;
  document.querySelectorAll('.font-card-option').forEach(c => c.classList.remove('selected'));
  const card = document.getElementById(`wizFont-${font}`);
  if (card) card.classList.add('selected');

  // Aplicar fuente en tiempo real
  setAppFont(font, true);
}

function selectWizardAnimations(enabled) {
  wizardData.animations = enabled;
  document.getElementById('wizAnim-enabled')?.classList.toggle('selected', enabled);
  document.getElementById('wizAnim-disabled')?.classList.toggle('selected', !enabled);

  // Aplicar animaciones en tiempo real
  setAppAnimations(enabled, true);
}

function getFontLabel(font) {
  const map = {
    modern: 'Inter Moderna',
    serif: 'Serif Elegante / Boutique',
    rounded: 'Nunito Redondeada',
    tech: 'JetBrains Mono Técnica'
  };
  return map[font] || font;
}

function getThemeLabel(theme) {
  const map = {
    light: '☀️ Blanco Moderno',
    dark: '🌙 Modo Oscuro',
    midnight: '🌌 Azul Noche',
    emerald: '🍃 Esmeralda POS',
    violet: '🔮 Violeta Neo',
    amber: '☕ Ámbar Cálido (Oro)'
  };
  return map[theme] || theme;
}

async function finishWizard() {
  const bizName = document.getElementById('wizBizName')?.value.trim() || '';
  const paper = document.querySelector('input[name="wizPaperRadio"]:checked')?.value || '80mm';
  const footerText = document.getElementById('wizFooter')?.value.trim() || '';

  // Configurar plantilla de ticket
  if (!state.config.ticketTemplate) state.config.ticketTemplate = getDefaultTemplate();
  const tpl = state.config.ticketTemplate;

  tpl.fields.businessName.value = bizName;
  tpl.fields.businessName.enabled = !!bizName;
  updateTopbarBrand(bizName, wizardData.logo);

  if (footerText) {
    tpl.fields.footer.value = footerText;
    tpl.fields.footer.enabled = true;
  } else {
    tpl.fields.footer.value = '';
    tpl.fields.footer.enabled = false;
  }

  if (wizardData.logo) {
    tpl.logo = wizardData.logo;
    tpl.showLogo = true;
  } else {
    tpl.showLogo = false;
  }

  state.config.paperWidth = paper;
  changePaperWidth(paper, false);

  // Si el usuario eligió rol secundario y especificó la IP del Principal:
  const secIp = document.getElementById('wizPrincipalIp')?.value.trim();
  if (wizardData.role === 'secundario' && secIp) {
    state.config.principalIp = secIp;
    const ipInp = document.getElementById('principalIpInput');
    if (ipInp) ipInp.value = secIp;
  }

  // Guardar rol
  selectMode(wizardData.role, false);

  // Aplicar tema, fuente y animaciones
  setAppTheme(wizardData.theme, true);
  setAppFont(wizardData.font, true);
  setAppAnimations(wizardData.animations, true);

  // Guardar en UI del personalizador y actualizar vista previa del ticket
  populateCustomizerUI();
  updatePreview();

  // Guardar en backend / disco
  await saveSettings(true);

  // Si es secundario con IP del Principal, sincronizar de inmediato
  if (wizardData.role === 'secundario' && state.config.principalIp) {
    syncFromPrincipal(state.config.principalIp, state.config.serverPort || 8989, true);
  }

  // Marcar como completado el onboarding
  localStorage.setItem('ticketprint_onboarded', 'true');

  // Cerrar asistente
  const modal = document.getElementById('onboardingModal');
  if (modal) modal.style.display = 'none';

  // Mostrar la interfaz principal ahora que ya está 100% configurada
  const appShell = document.getElementById('appShell');
  if (appShell) appShell.style.display = 'flex';

  playTicketBeep();
  showToast(`💎 ¡Configuración completada! Bienvenido a ${bizName || 'Imprent on LAN'}.`, 'success');
}

// CONTROL DE SONIDO
function updateSoundUI() {
  const icon = document.getElementById('soundIcon');
  if (icon) icon.textContent = soundEnabled ? '🔊' : '🔇';
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  localStorage.setItem('ticketprint_sound', soundEnabled ? 'true' : 'false');
  updateSoundUI();
  showToast(soundEnabled ? 'Avisos sonoros ACTIVADOS 🔊' : 'Avisos sonoros SILENCIADOS 🔇', 'info');
}

// NAVEGACIÓN POR PESTAÑAS
function setupTabs() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

      tab.classList.add('active');
      const targetId = tab.getAttribute('data-tab');
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add('active');

      if (targetId === 'tab-history') {
        loadHistory();
      } else if (targetId === 'tab-billing') {
        loadBillingHistory();
      }
    });
  });
}

// GESTOR DE CONTADOR SECUENCIAL DE TICKETS (0 AL INFINITO)
function getTicketCounter() {
  const val = localStorage.getItem('ticketprint_ticket_counter');
  if (val === null || val === undefined || val === '') return 0;
  const parsed = parseInt(val, 10);
  return isNaN(parsed) ? 0 : Math.max(0, parsed);
}

function setTicketCounter(val) {
  const n = Math.max(0, parseInt(val, 10) || 0);
  localStorage.setItem('ticketprint_ticket_counter', String(n));
  state.ticket.number = String(n);
  const badge = document.getElementById('currentTicketCounterBadge');
  if (badge) badge.textContent = `#${n}`;
  updatePreview();
  return n;
}

function incrementTicketCounter() {
  const next = getTicketCounter() + 1;
  return setTicketCounter(next);
}

function resetTicketCounterToZero() {
  if (confirm('¿Deseas reiniciar la numeración de tickets a 0?')) {
    setTicketCounter(0);
    showToast('Numeración de tickets reiniciada a 0', 'info');
  }
}

function initTicketCounter() {
  const current = getTicketCounter();
  setTicketCounter(current);
}

// CARGAR CONFIGURACIÓN
async function loadConfig() {
  try {
    if (state.isElectron) {
      const cfg = await window.electronAPI.getConfig();
      if (cfg) state.config = { ...state.config, ...cfg };
    } else {
      const res = await fetch('/api/config');
      if (res.ok) {
        const cfg = await res.json();
        state.config = { ...state.config, ...cfg };
      }
    }
  } catch (err) {
    console.warn('Error cargando configuración:', err);
  }

  if (!state.config.ticketTemplate) {
    state.config.ticketTemplate = getDefaultTemplate();
  }

  applyConfigToUI();
  populateCustomizerUI();
}

function getDefaultTemplate() {
  return {
    logo: '',
    logoSize: 'medium',
    showLogo: false,
    headerAlign: 'center',
    separatorStyle: 'dashed',
    currencySymbol: '€',
    fields: {
      businessName: { enabled: true, value: '', bold: true, size: 'large' },
      subtitle: { enabled: false, value: '' },
      cif: { enabled: true, label: 'CIF/NIF:', value: '' },
      address: { enabled: true, value: '' },
      phone: { enabled: true, label: 'TEL:', value: '' },
      emailOrWeb: { enabled: false, label: 'Web:', value: '' },
      ticketNumber: { enabled: true, prefix: 'TICKET #' },
      dateTime: { enabled: true },
      customer: { enabled: true, label: 'Cliente / Mesa:' },
      cashier: { enabled: true, label: 'Atendido por:' },
      paymentMethod: { enabled: true, label: 'Forma de pago:' },
      showTaxBreakdown: { enabled: true },
      taxRate: 21,
      footer: { enabled: true, value: '' },
      legalNote: { enabled: false, value: '' },
      endNotice: { enabled: true, value: '*** Fin de ticket ***' }
    },
    customFields: []
  };
}

// ACTUALIZAR MARCA Y LOGO DEL CLIENTE EN LA CABECERA (PICK ME, CLEAN & SUAVE)
function updateTopbarBrand(overrideName = null, overrideLogo = null) {
  const tpl = state.config?.ticketTemplate?.fields || {};
  const configuredName = tpl.businessName?.value?.trim() || '';
  const configuredLogo = state.config?.ticketTemplate?.logo || '';

  const bizName = overrideName !== null ? (overrideName || '').trim() : configuredName;
  const logo = overrideLogo !== null ? overrideLogo : configuredLogo;

  const nameEl = document.getElementById('topbarBizName');
  const subEl = document.getElementById('topbarBizSubtitle');
  const logoImg = document.getElementById('topbarCustomLogo');
  const defIcon = document.getElementById('topbarDefaultIcon');

  if (nameEl) {
    nameEl.textContent = bizName || 'Imprent on LAN';
  }
  if (subEl) {
    subEl.textContent = bizName ? 'Sistema de Tickets en Red' : 'Sistema de Impresión Multi-Equipo';
  }
  document.title = bizName ? `${bizName} - Imprent on LAN` : 'Imprent on LAN';

  if (logo && typeof logo === 'string' && logo.trim().length > 0) {
    if (logoImg) {
      logoImg.src = logo;
      logoImg.style.display = 'block';
    }
    if (defIcon) defIcon.style.display = 'none';
  } else {
    if (logoImg) {
      logoImg.src = '';
      logoImg.style.display = 'none';
    }
    if (defIcon) defIcon.style.display = 'flex';
  }
}

// APLICAR CONFIGURACIÓN A LA UI
function applyConfigToUI() {
  const cfg = state.config;
  selectMode(cfg.mode || 'secundario', false);

  const ipInput = document.getElementById('principalIpInput');
  const portInput = document.getElementById('serverPortInput');
  if (ipInput) ipInput.value = cfg.principalIp || '';
  if (portInput) portInput.value = cfg.serverPort || 8989;

  const paper = cfg.paperWidth || '80mm';
  const paperRadios = document.getElementsByName('paperWidthRadio');
  paperRadios.forEach(r => {
    r.checked = (r.value === paper);
  });
  changePaperWidth(paper, false);

  updateTopbarBrand();
}

// PERFIL DE OPERADOR
function initOperator() {
  const saved = localStorage.getItem('ticketprint_operator') || 'Operador 1';
  setOperator(saved);
}

function setOperator(name) {
  const clean = name.trim() || 'Operador 1';
  localStorage.setItem('ticketprint_operator', clean);
  const parts = clean.split(' ').filter(Boolean);
  const initials = parts.length > 1
    ? (parts[0][0] + parts[1][0]).toUpperCase()
    : clean.substring(0, 2).toUpperCase();

  const avatarEl = document.getElementById('userAvatarInitials');
  const displayEl = document.getElementById('currentOperatorDisplay');
  const cashierInput = document.getElementById('ticketCashier');

  if (avatarEl) avatarEl.textContent = initials || 'OP';
  if (displayEl) displayEl.textContent = clean;
  if (cashierInput) {
    cashierInput.value = clean;
    state.ticket.cashier = clean;
  }
}

function changeOperatorPrompt() {
  const current = localStorage.getItem('ticketprint_operator') || 'Operador 1';
  const newName = prompt('Introduce tu nombre o puesto para personalizar tus tickets:', current);
  if (newName !== null) {
    setOperator(newName);
    updatePreview();
    showToast(`Operador activo: ${newName.trim() || 'Operador 1'}`, 'success');
  }
}

// TEMAS VISUALES Y APARIENCIA
function initTheme() {
  const savedTheme = localStorage.getItem('ticketprint_theme') || 'dark';
  const savedFont = localStorage.getItem('ticketprint_font') || 'modern';
  const savedAccent = localStorage.getItem('ticketprint_accent') || '';
  const savedAnimations = localStorage.getItem('ticketprint_animations') !== 'false';

  setAppTheme(savedTheme, false);
  setAppFont(savedFont, false);
  setAppAnimations(savedAnimations, false);
  if (savedAccent) setCustomAccentColor(savedAccent, false);
}

function setAppTheme(theme, save = true) {
  document.body.classList.remove('theme-dark', 'theme-midnight', 'theme-emerald', 'theme-violet', 'theme-amber', 'theme-light');
  document.body.classList.add(`theme-${theme}`);

  document.querySelectorAll('.theme-card-option').forEach(c => c.classList.remove('selected'));
  const activeCard = document.getElementById(`themeCard-${theme}`);
  const wizCard = document.getElementById(`wizTheme-${theme}`);
  if (activeCard) activeCard.classList.add('selected');
  if (wizCard) wizCard.classList.add('selected');

  if (save) {
    localStorage.setItem('ticketprint_theme', theme);
  }
}

function setAppFont(font, save = true) {
  document.body.classList.remove('font-modern', 'font-rounded', 'font-tech', 'font-serif');
  document.body.classList.add(`font-${font}`);
  const sel = document.getElementById('appFontSelect');
  if (sel) sel.value = font;
  if (save) {
    localStorage.setItem('ticketprint_font', font);
  }
}

function setAppAnimations(enabled, save = true) {
  if (enabled) {
    document.body.classList.remove('no-animations');
  } else {
    document.body.classList.add('no-animations');
  }
  if (save) {
    localStorage.setItem('ticketprint_animations', enabled ? 'true' : 'false');
  }
}

function setCustomAccentColor(hex, save = true) {
  document.documentElement.style.setProperty('--primary', hex);
  document.documentElement.style.setProperty('--primary-glow', hex + '40');
  const picker = document.getElementById('accentColorPicker');
  const hexText = document.getElementById('accentColorHex');
  if (picker) picker.value = hex;
  if (hexText) hexText.textContent = hex;
  if (save) {
    localStorage.setItem('ticketprint_accent', hex);
    showToast('Color de acento personalizado aplicado', 'info');
  }
}

function resetAccentColor() {
  document.documentElement.style.removeProperty('--primary');
  document.documentElement.style.removeProperty('--primary-glow');
  localStorage.removeItem('ticketprint_accent');
  const picker = document.getElementById('accentColorPicker');
  const hexText = document.getElementById('accentColorHex');
  if (picker) picker.value = '#3b82f6';
  if (hexText) hexText.textContent = '#3b82f6';
  showToast('Color restablecido por defecto', 'info');
}

// SINCRONIZACIÓN EN RED
function renderSyncBanner() {
  const container = document.getElementById('syncBannerContainer');
  if (!container) return;

  if (state.config.mode === 'principal') {
    container.innerHTML = `
      <div class="sync-banner">
        <div class="sync-banner-info">
          <span class="sync-banner-icon">📡</span>
          <div>
            <div class="sync-banner-title">👑 PC Principal: Difusión de Diseño a la Red Local</div>
            <div class="sync-banner-desc">Envía tu logotipo, textos, plantilla de ticket y tema a todos los PCs secundarios conectados con 1 clic.</div>
          </div>
        </div>
        <button class="btn btn-primary" onclick="broadcastConfigToClients()">
          📤 Enviar Diseño a todos los PCs
        </button>
      </div>
    `;
  } else {
    container.innerHTML = `
      <div class="sync-banner" style="background: rgba(16, 185, 129, 0.08); border-color: rgba(16, 185, 129, 0.3);">
        <div class="sync-banner-info">
          <span class="sync-banner-icon">📥</span>
          <div>
            <div class="sync-banner-title">💻 PC Secundario: Sincronización con PC Principal</div>
            <div class="sync-banner-desc">Descarga el diseño oficial, logotipo y formato configurado por el PC Principal.</div>
          </div>
        </div>
        <button class="btn btn-success" onclick="syncFromPrincipal()">
          📥 Sincronizar desde PC Principal
        </button>
      </div>
    `;
  }
}

async function broadcastConfigToClients() {
  state.config.ticketTemplate = readTemplateFromUI();
  const currentTheme = localStorage.getItem('ticketprint_theme') || 'dark';

  try {
    // 1. Si estamos en Electron, emitir por IPC directamente (sin fallos de red file://)
    if (state.isElectron && window.electronAPI?.broadcastTemplate) {
      const result = await window.electronAPI.broadcastTemplate({
        ticketTemplate: state.config.ticketTemplate,
        appTheme: currentTheme
      });
      if (result && result.success) {
        showToast(`✅ ${result.message}`, 'success');
        return;
      } else {
        throw new Error(result?.error || 'Error al emitir configuración');
      }
    }

    // 2. Si es navegador web en red local
    const port = state.config.serverPort || 8989;
    const url = (window.location.protocol === 'http:' || window.location.protocol === 'https:')
      ? '/api/sync-to-clients'
      : `http://127.0.0.1:${port}/api/sync-to-clients`;

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ticketTemplate: state.config.ticketTemplate,
        appTheme: currentTheme
      })
    });
    const data = await res.json();
    if (res.ok && data.success) {
      showToast(`✅ ${data.message}`, 'success');
    } else {
      throw new Error(data.error || 'Error al emitir configuración');
    }
  } catch (err) {
    showToast('Error al difundir diseño: ' + err.message, 'error');
  }
}

async function syncFromPrincipal() {
  const ip = document.getElementById('principalIpInput').value.trim();
  const port = document.getElementById('serverPortInput').value.trim() || 8989;

  if (!ip) {
    showToast('Introduce primero la IP del PC Principal en los Ajustes de Red', 'error');
    return;
  }

  try {
    showToast('Descargando configuración del PC Principal...', 'info');
    const res = await fetch(`http://${ip}:${port}/api/sync-template`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (data.ticketTemplate) {
      state.config.ticketTemplate = data.ticketTemplate;
      populateCustomizerUI();
      updatePreview();
      await saveSettings(true);
    }

    if (data.appTheme) {
      setAppTheme(data.appTheme, true);
    }

    showToast('✅ ¡Diseño, logotipo y plantilla sincronizados con éxito!', 'success');
  } catch (err) {
    showToast(`Error al sincronizar: ${err.message}. Comprueba que el PC Principal tenga la app abierta.`, 'error');
  }
}

// FORMULARIO DEL PERSONALIZADOR DE TICKET
function populateCustomizerUI() {
  const tpl = state.config.ticketTemplate || getDefaultTemplate();
  const f = tpl.fields || {};

  document.getElementById('tplShowLogo').checked = Boolean(tpl.showLogo);
  document.getElementById('tplLogoSize').value = tpl.logoSize || 'medium';
  updateLogoUI(tpl.logo);

  document.getElementById('tplHeaderAlign').value = tpl.headerAlign || 'center';

  const sepRadios = document.getElementsByName('separatorRadio');
  sepRadios.forEach(r => {
    r.checked = (r.value === (tpl.separatorStyle || 'dashed'));
  });

  if (f.businessName) {
    document.getElementById('tplBizNameEnabled').checked = f.businessName.enabled !== false;
    document.getElementById('tplBizNameValue').value = f.businessName.value || '';
    document.getElementById('tplBizNameSize').value = f.businessName.size || 'large';
    document.getElementById('tplBizNameBold').checked = f.businessName.bold !== false;
  }
  if (f.subtitle) {
    document.getElementById('tplSubtitleEnabled').checked = Boolean(f.subtitle.enabled);
    document.getElementById('tplSubtitleValue').value = f.subtitle.value || '';
  }
  if (f.cif) {
    document.getElementById('tplCifEnabled').checked = f.cif.enabled !== false;
    document.getElementById('tplCifLabel').value = f.cif.label || 'CIF/NIF:';
    document.getElementById('tplCifValue').value = f.cif.value || '';
  }
  if (f.address) {
    document.getElementById('tplAddressEnabled').checked = f.address.enabled !== false;
    document.getElementById('tplAddressValue').value = f.address.value || '';
  }
  if (f.phone) {
    document.getElementById('tplPhoneEnabled').checked = f.phone.enabled !== false;
    document.getElementById('tplPhoneLabel').value = f.phone.label || 'TEL:';
    document.getElementById('tplPhoneValue').value = f.phone.value || '';
  }
  if (f.emailOrWeb) {
    document.getElementById('tplWebEnabled').checked = Boolean(f.emailOrWeb.enabled);
    document.getElementById('tplWebLabel').value = f.emailOrWeb.label || 'Web:';
    document.getElementById('tplWebValue').value = f.emailOrWeb.value || '';
  }

  if (f.ticketNumber) {
    document.getElementById('tplNumEnabled').checked = f.ticketNumber.enabled !== false;
    document.getElementById('tplNumPrefix').value = f.ticketNumber.prefix || 'TICKET #';
  }
  if (f.dateTime) {
    document.getElementById('tplDateEnabled').checked = f.dateTime.enabled !== false;
  }
  if (f.customer) {
    document.getElementById('tplCustEnabled').checked = f.customer.enabled !== false;
    document.getElementById('tplCustLabel').value = f.customer.label || 'Cliente / Mesa:';
    const lblCust = document.getElementById('lblCustomer');
    if (lblCust) lblCust.textContent = f.customer.label || 'Cliente / Mesa / Ref';
  }
  if (f.cashier) {
    document.getElementById('tplCashEnabled').checked = f.cashier.enabled !== false;
    document.getElementById('tplCashLabel').value = f.cashier.label || 'Atendido por:';
    const lblCash = document.getElementById('lblCashier');
    if (lblCash) lblCash.textContent = f.cashier.label || 'Atendido por';
  }
  if (f.paymentMethod) {
    document.getElementById('tplPayEnabled').checked = f.paymentMethod.enabled !== false;
    document.getElementById('tplPayLabel').value = f.paymentMethod.label || 'Forma de pago:';
  }

  document.getElementById('tplTaxBreakdown').checked = f.showTaxBreakdown ? f.showTaxBreakdown.enabled !== false : true;
  document.getElementById('tplTaxRate').value = f.taxRate || 21;
  document.getElementById('tplCurrency').value = tpl.currencySymbol || '€';
  document.getElementById('taxRateInput').value = f.taxRate || 21;
  state.ticket.taxRate = Number(f.taxRate) || 21;

  if (f.footer) {
    document.getElementById('tplFooterEnabled').checked = f.footer.enabled !== false;
    document.getElementById('tplFooterValue').value = f.footer.value || '';
  }
  if (f.legalNote) {
    document.getElementById('tplLegalEnabled').checked = Boolean(f.legalNote.enabled);
    document.getElementById('tplLegalValue').value = f.legalNote.value || '';
  }
  if (f.endNotice) {
    document.getElementById('tplEndNoticeEnabled').checked = f.endNotice.enabled !== false;
    document.getElementById('tplEndNoticeValue').value = f.endNotice.value !== undefined ? f.endNotice.value : '*** Fin de ticket ***';
  }

  renderCustomFieldsUI();
}

function readTemplateFromUI() {
  const tpl = state.config.ticketTemplate || getDefaultTemplate();

  tpl.showLogo = document.getElementById('tplShowLogo').checked;
  tpl.logoSize = document.getElementById('tplLogoSize').value;
  tpl.headerAlign = document.getElementById('tplHeaderAlign').value;
  tpl.separatorStyle = document.querySelector('input[name="separatorRadio"]:checked')?.value || 'dashed';
  tpl.currencySymbol = document.getElementById('tplCurrency').value.trim() || '€';

  tpl.fields = {
    businessName: {
      enabled: document.getElementById('tplBizNameEnabled').checked,
      value: document.getElementById('tplBizNameValue').value.trim(),
      size: document.getElementById('tplBizNameSize').value,
      bold: document.getElementById('tplBizNameBold').checked
    },
    subtitle: {
      enabled: document.getElementById('tplSubtitleEnabled').checked,
      value: document.getElementById('tplSubtitleValue').value.trim()
    },
    cif: {
      enabled: document.getElementById('tplCifEnabled').checked,
      label: document.getElementById('tplCifLabel').value.trim(),
      value: document.getElementById('tplCifValue').value.trim()
    },
    address: {
      enabled: document.getElementById('tplAddressEnabled').checked,
      value: document.getElementById('tplAddressValue').value.trim()
    },
    phone: {
      enabled: document.getElementById('tplPhoneEnabled').checked,
      label: document.getElementById('tplPhoneLabel').value.trim(),
      value: document.getElementById('tplPhoneValue').value.trim()
    },
    emailOrWeb: {
      enabled: document.getElementById('tplWebEnabled').checked,
      label: document.getElementById('tplWebLabel').value.trim(),
      value: document.getElementById('tplWebValue').value.trim()
    },
    ticketNumber: {
      enabled: document.getElementById('tplNumEnabled').checked,
      prefix: document.getElementById('tplNumPrefix').value
    },
    dateTime: {
      enabled: document.getElementById('tplDateEnabled').checked
    },
    customer: {
      enabled: document.getElementById('tplCustEnabled').checked,
      label: document.getElementById('tplCustLabel').value
    },
    cashier: {
      enabled: document.getElementById('tplCashEnabled').checked,
      label: document.getElementById('tplCashLabel').value
    },
    paymentMethod: {
      enabled: document.getElementById('tplPayEnabled').checked,
      label: document.getElementById('tplPayLabel').value
    },
    showTaxBreakdown: {
      enabled: document.getElementById('tplTaxBreakdown').checked
    },
    taxRate: parseFloat(document.getElementById('tplTaxRate').value) || 21,
    footer: {
      enabled: document.getElementById('tplFooterEnabled').checked,
      value: document.getElementById('tplFooterValue').value.trim()
    },
    legalNote: {
      enabled: document.getElementById('tplLegalEnabled').checked,
      value: document.getElementById('tplLegalValue').value.trim()
    },
    endNotice: {
      enabled: document.getElementById('tplEndNoticeEnabled').checked,
      value: document.getElementById('tplEndNoticeValue').value.trim()
    }
  };

  tpl.customFields = state.config.ticketTemplate?.customFields || [];
  return tpl;
}

// LOGO
function handleLogoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    const base64 = e.target.result;
    if (!state.config.ticketTemplate) state.config.ticketTemplate = getDefaultTemplate();
    state.config.ticketTemplate.logo = base64;
    state.config.ticketTemplate.showLogo = true;
    document.getElementById('tplShowLogo').checked = true;
    updateLogoUI(base64);
    updatePreview();
    updateTopbarBrand();
    showToast('Logotipo cargado correctamente', 'success');
  };
  reader.readAsDataURL(file);
}

function removeLogo() {
  if (!state.config.ticketTemplate) return;
  state.config.ticketTemplate.logo = '';
  state.config.ticketTemplate.showLogo = false;
  document.getElementById('tplShowLogo').checked = false;
  document.getElementById('logoFileInput').value = '';
  updateLogoUI('');
  updatePreview();
  updateTopbarBrand();
  showToast('Logo eliminado', 'info');
}

function updateLogoUI(base64) {
  const placeholder = document.getElementById('logoPlaceholder');
  const img = document.getElementById('logoImgPreview');
  const btnRemove = document.getElementById('btnRemoveLogo');

  if (base64) {
    if (placeholder) placeholder.style.display = 'none';
    if (img) { img.src = base64; img.style.display = 'block'; }
    if (btnRemove) btnRemove.style.display = 'inline-flex';
  } else {
    if (placeholder) placeholder.style.display = 'block';
    if (img) { img.src = ''; img.style.display = 'none'; }
    if (btnRemove) btnRemove.style.display = 'none';
  }
}

// CAMPOS PERSONALIZADOS EXTRAS
function renderCustomFieldsUI() {
  const container = document.getElementById('customFieldsContainer');
  if (!container) return;
  const list = state.config.ticketTemplate?.customFields || [];

  if (list.length === 0) {
    container.innerHTML = '<div style="font-size: 13px; color: var(--text-muted); padding: 8px 0;">No hay campos extras añadidos. Pulsa "+ Añadir Campo" arriba para añadir uno.</div>';
    return;
  }

  container.innerHTML = list.map((cf, idx) => `
    <div class="custom-field-item">
      <input type="checkbox" ${cf.enabled !== false ? 'checked' : ''} onchange="toggleCustomField(${idx}, this.checked)" title="Activar/Desactivar">
      <input type="text" class="form-control" style="flex: 1;" placeholder="Etiqueta (ej: Matrícula, WiFi, Garantía)" value="${escapeHtml(cf.label || '')}" oninput="updateCustomField(${idx}, 'label', this.value)">
      <input type="text" class="form-control" style="flex: 1.5;" placeholder="Valor (ej: 1234-XYZ, Clave123)" value="${escapeHtml(cf.value || '')}" oninput="updateCustomField(${idx}, 'value', this.value)">
      <button type="button" class="btn-delete-row" onclick="removeCustomField(${idx})" title="Eliminar este campo">🗑️</button>
    </div>
  `).join('');
}

function addCustomField() {
  if (!state.config.ticketTemplate) state.config.ticketTemplate = getDefaultTemplate();
  if (!Array.isArray(state.config.ticketTemplate.customFields)) {
    state.config.ticketTemplate.customFields = [];
  }
  state.config.ticketTemplate.customFields.push({ label: '', value: '', enabled: true });
  renderCustomFieldsUI();
  updatePreview();
}

function removeCustomField(idx) {
  if (state.config.ticketTemplate?.customFields) {
    state.config.ticketTemplate.customFields.splice(idx, 1);
    renderCustomFieldsUI();
    updatePreview();
  }
}

function updateCustomField(idx, prop, val) {
  if (state.config.ticketTemplate?.customFields[idx]) {
    state.config.ticketTemplate.customFields[idx][prop] = val;
    updatePreview();
  }
}

function toggleCustomField(idx, isChecked) {
  if (state.config.ticketTemplate?.customFields[idx]) {
    state.config.ticketTemplate.customFields[idx].enabled = isChecked;
    updatePreview();
  }
}

function updateCustomizerPreview() {
  state.config.ticketTemplate = readTemplateFromUI();
  updatePreview();
}

async function saveTemplateSettings() {
  state.config.ticketTemplate = readTemplateFromUI();
  await saveSettings(false);
  showToast('¡Plantilla y diseño de ticket guardados con éxito!', 'success');
}

// SELECCIÓN DE MODO (PRINCIPAL O SECUNDARIO)
function selectMode(mode, save = true) {
  state.config.mode = mode;

  const cardSec = document.getElementById('modeCardSecundario');
  const cardPrin = document.getElementById('modeCardPrincipal');
  const radioSec = document.getElementById('radioSecundario');
  const radioPrin = document.getElementById('radioPrincipal');
  const roleBadge = document.getElementById('roleBadge');
  const roleText = document.getElementById('roleText');
  const panelSec = document.getElementById('panelSecundarioConfig');
  const panelPrin = document.getElementById('panelPrincipalInfo');
  const badgePrinStatus = document.getElementById('badgePrincipalStatus');

  if (mode === 'principal') {
    cardPrin?.classList.add('selected');
    cardSec?.classList.remove('selected');
    if (radioPrin) radioPrin.checked = true;
    if (badgePrinStatus) badgePrinStatus.style.display = 'inline-block';

    if (roleBadge) {
      roleBadge.className = 'status-badge principal';
      roleText.textContent = '👑 PC Principal (Servidor)';
    }

    if (panelSec) panelSec.style.display = 'none';
    if (panelPrin) panelPrin.style.display = 'block';

    setConnectionStatus('online', 'Servidor de impresión activo en este PC');
    updatePrincipalUI();
    connectWebSocket('127.0.0.1', state.config.serverPort || 8989);
  } else {
    cardSec?.classList.add('selected');
    cardPrin?.classList.remove('selected');
    if (radioSec) radioSec.checked = true;
    if (badgePrinStatus) badgePrinStatus.style.display = 'none';

    if (roleBadge) {
      roleBadge.className = 'status-badge secundario';
      roleText.textContent = '💻 PC Secundario (Emisor)';
    }

    if (panelSec) panelSec.style.display = 'block';
    if (panelPrin) panelPrin.style.display = 'none';

    initSecondaryConnection();
  }

  renderSyncBanner();

  if (save) {
    saveSettings(true);
  }
}

async function updatePrincipalUI() {
  const container = document.getElementById('localIpsList');
  if (!container) return;
  try {
    let ips = [];
    if (state.isElectron) {
      ips = await window.electronAPI.getLocalIps();
    } else {
      const res = await fetch('/api/status');
      if (res.ok) {
        const data = await res.json();
        ips = data.localIps || [];
      }
    }

    if (ips.length > 0) {
      container.innerHTML = ips.map(ip => `
        <span style="background: var(--primary-light); color: var(--primary); padding: 4px 10px; border-radius: 6px; display: inline-flex; align-items: center; gap: 6px;">
          ${ip}
          <button onclick="copyToClipboard('${ip}')" style="background: transparent; border: none; cursor: pointer; font-size: 14px;" title="Copiar IP">📋</button>
        </span>
      `).join(' ');
    } else {
      container.innerHTML = '<span>127.0.0.1 (Localhost)</span>';
    }
  } catch (e) {
    container.innerHTML = '<span>No se pudieron obtener las IPs locales</span>';
  }
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text);
  showToast(`IP copiada al portapapeles: ${text}`, 'success');
}

function initSecondaryConnection() {
  const ip = document.getElementById('principalIpInput')?.value.trim();
  const port = document.getElementById('serverPortInput')?.value.trim() || 8989;

  if (!ip) {
    setConnectionStatus('offline', 'Indica la IP del PC Principal');
    return;
  }

  testConnection(false);
}

// SINCRONIZACIÓN COMPLETA DESDE EL PC PRINCIPAL (HISTORIAL, PLANTILLA, LOGO, CONTADOR)
async function syncFromPrincipal(ip, port = 8989, notify = false) {
  if (!ip) return false;
  try {
    // 1. Obtener plantilla, logotipo y dimensiones desde el PC Principal
    const resTpl = await fetch(`http://${ip}:${port}/api/sync-template`, { cache: 'no-store' });
    if (resTpl.ok) {
      const tplData = await resTpl.json();
      if (tplData.ticketTemplate) {
        state.config.ticketTemplate = tplData.ticketTemplate;
      }
      if (tplData.paperWidth) {
        state.config.paperWidth = tplData.paperWidth;
        changePaperWidth(tplData.paperWidth, false);
      }
      if (tplData.appTheme) {
        setAppTheme(tplData.appTheme, false);
      }
    }

    // 2. Cargar historial centralizado desde el PC Principal
    await loadHistory();

    // 3. Sincronizar contador de tickets para que coincida exactamente con el Principal
    if (Array.isArray(currentHistoryList) && currentHistoryList.length > 0) {
      const lastItem = currentHistoryList[0];
      const lastNum = parseInt(String(lastItem.ticketNumber).replace(/\D/g, ''), 10);
      if (!isNaN(lastNum)) {
        setTicketCounter(lastNum + 1);
      }
    }

    // 4. Refrescar interfaz y guardar en disco
    state.config.principalIp = ip;
    state.config.serverPort = port;
    populateCustomizerUI();
    updatePreview();
    updateTopbarBrand();
    saveSettings(true);

    if (notify) {
      showToast('🔄 Sincronizado con el PC Principal: plantilla, logotipo e historial al día', 'success');
    }
    return true;
  } catch (err) {
    console.warn('[syncFromPrincipal] Error:', err.message);
    return false;
  }
}

async function testConnection(notify = true) {
  const ip = document.getElementById('principalIpInput')?.value.trim();
  const port = document.getElementById('serverPortInput')?.value.trim() || 8989;

  if (!ip) {
    if (notify) showToast('Por favor introduce la IP del PC Principal', 'error');
    setConnectionStatus('offline', 'Falta IP del PC Principal');
    return;
  }

  setConnectionStatus('checking', `Conectando a ${ip}:${port}...`);

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const res = await fetch(`http://${ip}:${port}/api/status`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      setConnectionStatus('online', `Conectado al PC Principal (${ip})`);
      connectWebSocket(ip, port);
      // Sincronizar plantilla, logo e historial desde el PC Principal
      await syncFromPrincipal(ip, port, notify);
    } else {
      throw new Error(`Respuesta HTTP ${res.status}`);
    }
  } catch (err) {
    setConnectionStatus('offline', `No se pudo conectar con ${ip}:${port}`);
    if (notify) {
      showToast(`No se pudo conectar con el PC Principal (${ip}:${port}). Comprueba que esté encendido.`, 'error');
    }
  }
}

function playTicketBeep() {
  if (!soundEnabled) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const audioCtx = new AudioContext();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(784, audioCtx.currentTime); // G5
    osc.frequency.setValueAtTime(1046.50, audioCtx.currentTime + 0.12); // C6

    gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();
    osc.stop(audioCtx.currentTime + 0.4);
  } catch (e) {}
}

function connectWebSocket(ip, port) {
  if (state.ws) {
    try { state.ws.close(); } catch (e) {}
  }

  try {
    const wsUrl = `ws://${ip}:${port}`;
    state.ws = new WebSocket(wsUrl);

    state.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.event === 'welcome') {
          if (msg.data?.license) {
            applyLicenseStatus(msg.data.license);
          }
          if (state.config.mode === 'secundario') {
            if (msg.data?.ticketTemplate) {
              state.config.ticketTemplate = msg.data.ticketTemplate;
              populateCustomizerUI();
              updatePreview();
              updateTopbarBrand();
              saveSettings(true);
            }
            if (msg.data?.paperWidth) {
              state.config.paperWidth = msg.data.paperWidth;
              changePaperWidth(msg.data.paperWidth, false);
            }
            loadHistory();
          }
        } else if (msg.event === 'license_updated') {
          applyLicenseStatus(msg.data);
        } else if (msg.event === 'ticket_received') {
          playTicketBeep();
        } else if (msg.event === 'ticket_printed') {
          playTicketBeep();
          showToast(`🖨️ Ticket ${msg.data.ticketNumber} impreso (${msg.data.status})`, 'success');
          loadHistory();
          if (msg.data?.ticketNumber) {
            const printedNum = parseInt(String(msg.data.ticketNumber).replace(/\D/g, ''), 10);
            if (!isNaN(printedNum)) {
              const current = getTicketCounter();
              if (printedNum >= current) {
                setTicketCounter(printedNum + 1);
              }
            }
          }
        } else if (msg.event === 'template_synced') {
          if (state.config.mode === 'secundario') {
            if (msg.data?.ticketTemplate) {
              state.config.ticketTemplate = msg.data.ticketTemplate;
              populateCustomizerUI();
              updatePreview();
              updateTopbarBrand();
              saveSettings(true);
            }
            if (msg.data?.paperWidth) {
              state.config.paperWidth = msg.data.paperWidth;
              changePaperWidth(msg.data.paperWidth, false);
            }
            if (msg.data?.appTheme) {
              setAppTheme(msg.data.appTheme, true);
            }
            playTicketBeep();
            showToast('🔄 ¡Diseño, logotipo y plantilla actualizados en vivo desde el PC Principal!', 'success');
          }
        }
      } catch (e) {}
    };

    state.ws.onerror = () => {};
  } catch (e) {}
}

async function autoDiscoverPrincipal() {
  const statusEl = document.getElementById('discoveryStatus');
  if (statusEl) statusEl.innerHTML = '<span style="color: var(--primary);">🔍 Buscando PC Principal en la red local...</span>';

  try {
    let result = null;
    if (state.isElectron) {
      result = await window.electronAPI.discoverPrincipal();
    } else {
      const res = await fetch('/api/discover-principal');
      if (res.ok) result = await res.json();
    }

    if (result && result.found) {
      const ipInput = document.getElementById('principalIpInput');
      const portInput = document.getElementById('serverPortInput');
      if (ipInput) ipInput.value = result.ip;
      if (portInput && result.port) portInput.value = result.port;

      if (statusEl) statusEl.innerHTML = `<span style="color: var(--success); font-weight: bold;">✅ ¡PC Principal encontrado en ${result.ip}!</span>`;
      showToast(`PC Principal detectado automáticamente en ${result.ip}`, 'success');
      saveSettings(true);
      testConnection(false);
    } else {
      if (statusEl) statusEl.innerHTML = '<span style="color: var(--danger);">⚠️ No se encontró automáticamente ningún PC Principal activo. Introduce la IP manualmente.</span>';
    }
  } catch (err) {
    if (statusEl) statusEl.innerHTML = `<span style="color: var(--danger);">Error en la búsqueda: ${err.message}</span>`;
  }
}

function setConnectionStatus(status, text) {
  const dot = document.getElementById('connectionDot');
  const txt = document.getElementById('connectionText');
  if (txt) txt.textContent = text;

  if (dot) {
    if (status === 'online') {
      dot.className = 'status-dot green';
      state.isConnected = true;
    } else if (status === 'checking') {
      dot.className = 'status-dot yellow';
      state.isConnected = false;
    } else {
      dot.className = 'status-dot red';
      state.isConnected = false;
    }
  }
}

async function scanPrinters() {
  const select = document.getElementById('printerSelect');
  if (!select) return;
  select.innerHTML = '<option value="">(Escaneando impresoras...)</option>';

  try {
    let printers = [];
    let savedPrinter = state.config.selectedPrinter;

    if (state.isElectron) {
      printers = await window.electronAPI.getPrinters();
    } else {
      const res = await fetch('/api/printers');
      if (res.ok) {
        const data = await res.json();
        printers = data.printers || [];
        if (!savedPrinter) savedPrinter = data.selectedPrinter;
      }
    }

    select.innerHTML = '';
    if (printers.length === 0) {
      select.innerHTML = '<option value="">No se detectaron impresoras instaladas</option>';
      return;
    }

    printers.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.name;
      opt.textContent = `${p.name} ${p.isDefault ? '⭐ (Predeterminada)' : ''}`;
      if (savedPrinter ? p.name === savedPrinter : p.isDefault) {
        opt.selected = true;
      }
      select.appendChild(opt);
    });

    state.config.selectedPrinter = select.value;
  } catch (err) {
    select.innerHTML = '<option value="">Error al escanear impresoras</option>';
  }
}

function changePaperWidth(width, updateConfig = true) {
  state.config.paperWidth = width;
  const paperEl = document.getElementById('receiptPaper');
  const badgeEl = document.getElementById('previewPaperBadge');

  if (paperEl) {
    if (width === '58mm') {
      paperEl.className = 'receipt-paper w58';
      if (badgeEl) badgeEl.textContent = '58mm Térmico';
    } else {
      paperEl.className = 'receipt-paper w80';
      if (badgeEl) badgeEl.textContent = '80mm Térmico';
    }
  }

  if (updateConfig) updatePreview();
}

// ARTÍCULOS DEL TICKET
function addItemFromInputs() {
  const nameInput = document.getElementById('newItemName');
  const qtyInput = document.getElementById('newItemQty');
  const priceInput = document.getElementById('newItemPrice');

  const name = nameInput?.value.trim();
  const qty = parseInt(qtyInput?.value) || 1;
  const price = parseFloat(priceInput?.value) || 0;

  if (!name) {
    showToast('Escribe el concepto o artículo', 'error');
    if (nameInput) nameInput.focus();
    return;
  }

  state.ticket.items.push({
    name,
    qty,
    price,
    total: qty * price
  });

  if (nameInput) { nameInput.value = ''; nameInput.focus(); }
  if (qtyInput) qtyInput.value = '1';
  if (priceInput) priceInput.value = '';

  renderItemsTable();
  updatePreview();
}

function updateItemQty(index, delta) {
  if (!state.ticket.items[index]) return;
  state.ticket.items[index].qty += delta;
  if (state.ticket.items[index].qty <= 0) {
    state.ticket.items.splice(index, 1);
  } else {
    state.ticket.items[index].total = state.ticket.items[index].qty * state.ticket.items[index].price;
  }
  renderItemsTable();
  updatePreview();
}

function deleteItem(index) {
  state.ticket.items.splice(index, 1);
  renderItemsTable();
  updatePreview();
}

function renderItemsTable() {
  const tbody = document.getElementById('itemsTableBody');
  if (!tbody) return;
  const currency = state.config.ticketTemplate?.currencySymbol || '€';

  if (state.ticket.items.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color: var(--text-muted); padding: 18px;">El ticket está vacío. Escribe un concepto arriba y pulsa "+ Añadir".</td></tr>`;
    return;
  }

  tbody.innerHTML = state.ticket.items.map((item, idx) => `
    <tr>
      <td>
        <div class="qty-control">
          <button class="btn-qty" onclick="updateItemQty(${idx}, -1)">-</button>
          <span style="min-width: 22px; text-align: center; font-weight: 600;">${item.qty}</span>
          <button class="btn-qty" onclick="updateItemQty(${idx}, 1)">+</button>
        </div>
      </td>
      <td><strong>${escapeHtml(item.name)}</strong></td>
      <td style="text-align: right;">${item.price.toFixed(2)}${currency}</td>
      <td style="text-align: right; font-weight: bold;">${item.total.toFixed(2)}${currency}</td>
      <td style="text-align: center;">
        <button class="btn-delete-row" onclick="deleteItem(${idx})" title="Eliminar fila">🗑️</button>
      </td>
    </tr>
  `).join('');
}

// VISTA PREVIA DEL TICKET TÉRMICO
function updatePreview() {
  const tpl = state.config.ticketTemplate || getDefaultTemplate();
  const f = tpl.fields || {};
  const currency = tpl.currencySymbol || '€';
  const paymentMethod = document.getElementById('paymentMethod')?.value || 'Efectivo';
  const taxRate = parseFloat(document.getElementById('taxRateInput')?.value) || (f.taxRate || 21);

  // 1. Alineación
  const prevHeaderWrapper = document.getElementById('prevHeaderWrapper');
  if (prevHeaderWrapper) {
    prevHeaderWrapper.className = tpl.headerAlign === 'left' ? 'receipt-left' : 'receipt-center';
  }

  // 2. Logo
  const prevLogoImg = document.getElementById('prevLogoImg');
  if (prevLogoImg) {
    if (tpl.showLogo && tpl.logo) {
      prevLogoImg.src = tpl.logo;
      prevLogoImg.style.display = 'block';
      let maxW = '45mm';
      if (tpl.logoSize === 'small') maxW = '30mm';
      if (tpl.logoSize === 'large') maxW = '65mm';
      prevLogoImg.style.maxWidth = maxW;
    } else {
      prevLogoImg.style.display = 'none';
      prevLogoImg.src = '';
    }
  }

  // 3. Encabezado de negocio
  const prevBizName = document.getElementById('prevBizName');
  if (prevBizName) {
    const bName = f.businessName?.value || '';
    if (f.businessName?.enabled && bName) {
      prevBizName.textContent = bName;
      prevBizName.style.display = 'block';
      prevBizName.style.fontWeight = f.businessName.bold !== false ? '900' : 'normal';
      let s = '17px';
      if (f.businessName.size === 'normal') s = '14px';
      if (f.businessName.size === 'xlarge') s = '20px';
      prevBizName.style.fontSize = s;
    } else {
      prevBizName.style.display = 'none';
    }
  }

  const prevSubtitle = document.getElementById('prevSubtitle');
  if (prevSubtitle) {
    if (f.subtitle?.enabled && f.subtitle.value) {
      prevSubtitle.textContent = f.subtitle.value;
      prevSubtitle.style.display = 'block';
    } else {
      prevSubtitle.style.display = 'none';
    }
  }

  const prevBizAddress = document.getElementById('prevBizAddress');
  if (prevBizAddress) {
    if (f.address?.enabled && f.address.value) {
      prevBizAddress.textContent = f.address.value;
      prevBizAddress.style.display = 'block';
    } else {
      prevBizAddress.style.display = 'none';
    }
  }

  const prevBizCif = document.getElementById('prevBizCif');
  if (prevBizCif) {
    if (f.cif?.enabled && f.cif.value) {
      prevBizCif.textContent = `${f.cif.label || 'CIF:'} ${f.cif.value}`;
      prevBizCif.style.display = 'block';
    } else {
      prevBizCif.style.display = 'none';
    }
  }

  const prevBizPhone = document.getElementById('prevBizPhone');
  if (prevBizPhone) {
    if (f.phone?.enabled && f.phone.value) {
      prevBizPhone.textContent = `${f.phone.label || 'TEL:'} ${f.phone.value}`;
      prevBizPhone.style.display = 'block';
    } else {
      prevBizPhone.style.display = 'none';
    }
  }

  const prevBizWeb = document.getElementById('prevBizWeb');
  if (prevBizWeb) {
    if (f.emailOrWeb?.enabled && f.emailOrWeb.value) {
      prevBizWeb.textContent = `${f.emailOrWeb.label || 'Web:'} ${f.emailOrWeb.value}`;
      prevBizWeb.style.display = 'block';
    } else {
      prevBizWeb.style.display = 'none';
    }
  }

  const prevHeaderDivider = document.getElementById('prevHeaderDivider');
  const hasHeaderContent = (tpl.showLogo && tpl.logo) ||
    (f.businessName?.enabled && f.businessName.value) ||
    (f.subtitle?.enabled && f.subtitle.value) ||
    (f.address?.enabled && f.address.value) ||
    (f.cif?.enabled && f.cif.value) ||
    (f.phone?.enabled && f.phone.value) ||
    (f.emailOrWeb?.enabled && f.emailOrWeb.value);

  if (prevHeaderDivider) {
    prevHeaderDivider.style.display = hasHeaderContent ? 'block' : 'none';
  }

  // 4. Metadatos
  const prevTicketNumContainer = document.getElementById('prevTicketNumContainer');
  if (prevTicketNumContainer) {
    if (f.ticketNumber?.enabled !== false) {
      const pfx = f.ticketNumber?.prefix || 'TICKET #';
      const numRaw = (state.ticket.number !== undefined && state.ticket.number !== null && state.ticket.number !== '') ? String(state.ticket.number) : '0';
      const numClean = numRaw.replace(/^#/, '');
      document.getElementById('prevTicketNum').textContent = `${pfx}${numClean}`;
      prevTicketNumContainer.style.display = 'inline';
    } else {
      prevTicketNumContainer.style.display = 'none';
    }
  }

  const prevTicketDate = document.getElementById('prevTicketDate');
  if (prevTicketDate) {
    if (f.dateTime?.enabled !== false) {
      prevTicketDate.textContent = new Date().toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' });
      prevTicketDate.style.display = 'inline';
    } else {
      prevTicketDate.style.display = 'none';
    }
  }

  const prevCustomer = document.getElementById('prevCustomer');
  if (prevCustomer) {
    if (f.customer?.enabled !== false && state.ticket.customer) {
      prevCustomer.textContent = `${f.customer?.label || 'Cliente:'} ${state.ticket.customer}`;
      prevCustomer.style.display = 'block';
    } else {
      prevCustomer.style.display = 'none';
    }
  }

  const prevCashier = document.getElementById('prevCashier');
  if (prevCashier) {
    if (f.cashier?.enabled !== false && state.ticket.cashier) {
      prevCashier.textContent = `${f.cashier?.label || 'Atendido por:'} ${state.ticket.cashier}`;
      prevCashier.style.display = 'block';
    } else {
      prevCashier.style.display = 'none';
    }
  }

  // Campos extras
  const prevCustomFields = document.getElementById('prevCustomFields');
  if (prevCustomFields) {
    const extras = (tpl.customFields || []).filter(cf => cf.enabled && (cf.label || cf.value));
    if (extras.length > 0) {
      prevCustomFields.innerHTML = extras.map(cf => `
        <div><strong>${escapeHtml(cf.label)}:</strong> ${escapeHtml(cf.value)}</div>
      `).join('');
      prevCustomFields.style.display = 'block';
    } else {
      prevCustomFields.innerHTML = '';
      prevCustomFields.style.display = 'none';
    }
  }

  // 5. Filas de artículos
  const prevTbody = document.getElementById('prevItemsBody');
  let subtotal = 0;

  if (state.ticket.items.length === 0) {
    if (prevTbody) prevTbody.innerHTML = `<tr><td colspan="2" style="text-align: center; color: #888; padding: 10px 0;">(Ticket vacío)</td></tr>`;
  } else {
    if (prevTbody) prevTbody.innerHTML = state.ticket.items.map(item => {
      subtotal += item.total;
      return `
        <tr>
          <td class="receipt-left"><strong>${item.qty}x</strong> ${escapeHtml(item.name)}</td>
          <td class="receipt-right">${item.total.toFixed(2)}${currency}</td>
        </tr>
      `;
    }).join('');
  }

  // 6. Totales e impuestos
  const showTax = f.showTaxBreakdown ? f.showTaxBreakdown.enabled !== false : true;
  const taxAmount = subtotal * (taxRate / 100);
  const grandTotal = subtotal + taxAmount;

  const rowTax1 = document.getElementById('prevTaxRow1');
  const rowTax2 = document.getElementById('prevTaxRow2');
  if (rowTax1 && rowTax2) {
    rowTax1.style.display = showTax ? 'table-row' : 'none';
    rowTax2.style.display = showTax ? 'table-row' : 'none';
  }

  document.getElementById('prevSubtotal').textContent = `${subtotal.toFixed(2)}${currency}`;
  document.getElementById('prevTaxLabel').textContent = `I.V.A. (${taxRate}%):`;
  document.getElementById('prevTaxAmount').textContent = `${taxAmount.toFixed(2)}${currency}`;
  document.getElementById('prevTotal').textContent = `${grandTotal.toFixed(2)}${currency}`;
  document.getElementById('totalDisplay').textContent = `${grandTotal.toFixed(2)}${currency}`;

  const prevPayRow = document.getElementById('prevPayRow');
  const prevPayLabel = document.getElementById('prevPayLabel');
  const prevPayment = document.getElementById('prevPayment');
  if (prevPayRow) {
    if (f.paymentMethod?.enabled !== false) {
      prevPayRow.style.display = 'table-row';
      if (prevPayLabel) prevPayLabel.textContent = f.paymentMethod?.label || 'Forma de pago:';
      if (prevPayment) prevPayment.textContent = paymentMethod;
    } else {
      prevPayRow.style.display = 'none';
    }
  }

  // 7. Pie de ticket
  const prevFooterDivider = document.getElementById('prevFooterDivider');
  const prevFooter = document.getElementById('prevFooter');
  const prevLegal = document.getElementById('prevLegal');
  const prevEndNotice = document.getElementById('prevEndNotice');

  const hasFoot = f.footer?.enabled && f.footer.value;
  const hasLegal = f.legalNote?.enabled && f.legalNote.value;
  const hasEnd = f.endNotice?.enabled && f.endNotice.value;

  if (prevFooter) {
    if (hasFoot) {
      prevFooter.textContent = f.footer.value;
      prevFooter.style.display = 'block';
    } else {
      prevFooter.style.display = 'none';
    }
  }

  if (prevLegal) {
    if (hasLegal) {
      prevLegal.textContent = f.legalNote.value;
      prevLegal.style.display = 'block';
    } else {
      prevLegal.style.display = 'none';
    }
  }

  if (prevEndNotice) {
    if (hasEnd) {
      prevEndNotice.textContent = f.endNotice.value;
      prevEndNotice.style.display = 'block';
    } else {
      prevEndNotice.style.display = 'none';
    }
  }

  if (prevFooterDivider) {
    prevFooterDivider.style.display = (hasFoot || hasLegal) ? 'block' : 'none';
  }

  const sepStyle = tpl.separatorStyle || 'dashed';
  let dividerBorder = '1px dashed #000';
  if (sepStyle === 'solid') dividerBorder = '1px solid #000';
  if (sepStyle === 'double') dividerBorder = '3px double #000';
  if (sepStyle === 'none') dividerBorder = 'none';

  document.querySelectorAll('.receipt-divider').forEach(el => {
    el.style.borderTop = dividerBorder;
  });

  state.ticket.subtotal = subtotal;
  state.ticket.taxRate = taxRate;
  state.ticket.total = grandTotal;
}

// GUARDAR AJUSTES GENERALES
async function saveSettings(silent = false) {
  const mode = state.config.mode;
  const principalIp = document.getElementById('principalIpInput')?.value.trim() || '';
  const serverPort = parseInt(document.getElementById('serverPortInput')?.value) || 8989;
  const selectedPrinter = document.getElementById('printerSelect')?.value || '';
  const paperWidth = document.querySelector('input[name="paperWidthRadio"]:checked')?.value || '80mm';
  const ticketTemplate = state.config.ticketTemplate || readTemplateFromUI();

  const newConfig = {
    mode,
    principalIp,
    serverPort,
    selectedPrinter,
    paperWidth,
    ticketTemplate
  };

  state.config = newConfig;
  updateTopbarBrand();

  try {
    if (state.isElectron) {
      await window.electronAPI.saveConfig(newConfig);
    } else {
      await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig)
      });
    }
    if (!silent) showToast('Ajustes guardados correctamente', 'success');
  } catch (err) {
    if (!silent) showToast('Error guardando ajustes: ' + err.message, 'error');
  }
}

// IMPRIMIR TICKET ACTUAL
async function printCurrentTicket() {
  if (state.license.isBlocked && !state.license.emergencyUnlocked) {
    showToast('Terminal bloqueada: ' + (state.license.blockReason || 'Cuota mensual pendiente'), 'error');
    return;
  }

  if (state.ticket.items.length === 0) {
    showToast('Añade al menos un concepto al ticket antes de imprimir', 'error');
    return;
  }

  const btn = document.getElementById('btnPrintTicket');
  const statusMsg = document.getElementById('printStatusMsg');
  const copies = parseInt(document.getElementById('printCopiesSelect')?.value) || 1;

  if (btn) btn.disabled = true;
  if (statusMsg) statusMsg.innerHTML = '<span style="color: var(--primary);">⏳ Enviando ticket...</span>';

  // Animación física de salida de papel continuo de la impresora
  const paperEl = document.getElementById('receiptPaper');
  if (paperEl) {
    paperEl.classList.remove('printing-anim');
    void paperEl.offsetWidth; // reiniciar animación
    paperEl.classList.add('printing-anim');
  }

  const ticketPayload = {
    number: state.ticket.number,
    date: new Date().toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }),
    customer: state.ticket.customer,
    cashier: state.ticket.cashier,
    paymentMethod: document.getElementById('paymentMethod')?.value || 'Efectivo',
    items: state.ticket.items,
    subtotal: state.ticket.subtotal,
    taxRate: state.ticket.taxRate,
    total: state.ticket.total
  };

  try {
    let result = null;

    if (state.config.mode === 'principal') {
      if (!state.config.selectedPrinter) {
        throw new Error('Selecciona una impresora en la pestaña "Impresora de Windows"');
      }

      if (state.isElectron) {
        for (let c = 0; c < copies; c++) {
          result = await window.electronAPI.printTicketLocal({
            ticket: ticketPayload,
            template: state.config.ticketTemplate,
            paperWidth: state.config.paperWidth,
            printerName: state.config.selectedPrinter
          });
        }
      } else {
        const res = await fetch('/api/print', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ticket: ticketPayload,
            copies,
            templateOverride: state.config.ticketTemplate
          })
        });
        result = await res.json();
      }
    } else {
      const ip = document.getElementById('principalIpInput')?.value.trim();
      const port = document.getElementById('serverPortInput')?.value.trim() || 8989;

      if (!ip) {
        throw new Error('Indica la IP del PC Principal en los Ajustes de Red');
      }

      const res = await fetch(`http://${ip}:${port}/api/print`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticket: ticketPayload,
          copies,
          templateOverride: state.config.ticketTemplate,
          paperWidthOverride: state.config.paperWidth
        })
      });

      result = await res.json();
      if (!res.ok || !result.success) {
        throw new Error(result.error || 'Fallo de impresión en el PC Principal');
      }
    }

    showToast(`✅ ¡Ticket #${ticketPayload.number} impreso con éxito!`, 'success');
    if (statusMsg) statusMsg.innerHTML = `<span style="color: var(--success); font-weight: bold;">✅ Ticket #${ticketPayload.number} impreso</span>`;

    // Respaldo de historial en localStorage
    try {
      const backup = JSON.parse(localStorage.getItem('ticketprint_history_backup') || '[]');
      backup.unshift({
        id: Date.now().toString(),
        ticketNumber: ticketPayload.number,
        date: ticketPayload.date,
        customer: ticketPayload.customer || 'Mostrador',
        total: (typeof ticketPayload.total === 'number' ? ticketPayload.total.toFixed(2) + '€' : ticketPayload.total) || '0.00€',
        origin: 'Local (Este PC)',
        printer: state.config.selectedPrinter || 'Impresora Local',
        status: 'Impreso con éxito',
        ticketData: ticketPayload
      });
      localStorage.setItem('ticketprint_history_backup', JSON.stringify(backup.slice(0, 150)));
    } catch (e) {}

    // Siguiente ticket: avanzar contador secuencial (0 al infinito)
    incrementTicketCounter();
    state.ticket.items = [];
    renderItemsTable();
    updatePreview();
    loadHistory();

  } catch (err) {
    showToast(`❌ Error: ${err.message}`, 'error');
    if (statusMsg) statusMsg.innerHTML = `<span style="color: var(--danger);">❌ Error: ${err.message}</span>`;
  } finally {
    if (btn) btn.disabled = false;
  }
}

// IMPRIMIR TICKET DE PRUEBA
async function printTestTicket() {
  const printer = document.getElementById('printerSelect')?.value;
  if (!printer) {
    showToast('Selecciona primero una impresora en el desplegable', 'error');
    return;
  }

  showToast('Enviando ticket de prueba a la impresora...', 'info');

  const testTicket = {
    number: 'TEST-' + Math.floor(100 + Math.random() * 900),
    date: new Date().toLocaleString('es-ES'),
    customer: 'Prueba de Diagnóstico',
    cashier: 'Imprent on LAN',
    paymentMethod: 'Test',
    items: [
      { name: 'Prueba de Rollo Térmico', qty: 1, price: 0.00, total: 0.00 },
      { name: `Impresora: ${printer}`, qty: 1, price: 0.00, total: 0.00 },
      { name: `Ancho: ${state.config.paperWidth || '80mm'}`, qty: 1, price: 0.00, total: 0.00 }
    ],
    subtotal: 0.00,
    taxRate: 0,
    total: 0.00
  };

  try {
    if (state.isElectron) {
      await window.electronAPI.printTicketLocal({
        ticket: testTicket,
        template: state.config.ticketTemplate,
        paperWidth: state.config.paperWidth,
        printerName: printer
      });
    } else {
      await fetch('/api/test-print', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticket: testTicket, templateOverride: state.config.ticketTemplate })
      });
    }
    showToast('Ticket de prueba impreso correctamente', 'success');
  } catch (err) {
    showToast('Error en prueba: ' + err.message, 'error');
  }
}

// HISTORIAL Y REIMPRESIÓN
let currentHistoryList = [];

async function loadHistory() {
  const tbody = document.getElementById('historyTableBody');
  if (!tbody) return;

  let list = [];
  const isSecondary = state.config.mode === 'secundario';
  const principalIp = document.getElementById('principalIpInput')?.value.trim() || state.config.principalIp || '127.0.0.1';
  const port = document.getElementById('serverPortInput')?.value.trim() || state.config.serverPort || 8989;

  // 1. Si es modo Secundario: Consultar SIEMPRE el historial centralizado al PC Principal
  if (isSecondary) {
    try {
      const res = await fetch(`http://${principalIp}:${port}/api/history`, { cache: 'no-store' });
      if (res.ok) {
        const httpList = await res.json();
        if (Array.isArray(httpList)) {
          list = httpList;
        }
      }
    } catch (e) {
      console.warn('Error leyendo historial centralizado del PC Principal:', e.message);
    }
  } else {
    // 2. Si es PC Principal en Electron: Consultar historial de historyManager por IPC
    if (state.isElectron && window.electronAPI?.getHistory) {
      try {
        const ipcHistory = await window.electronAPI.getHistory();
        if (Array.isArray(ipcHistory) && ipcHistory.length > 0) {
          list = ipcHistory;
        }
      } catch (err) {
        console.warn('Error leyendo historial por IPC:', err);
      }
    }
  }

  // 3. Fallback en caso de desconexión momentánea: consultar endpoint HTTP local
  if (!Array.isArray(list) || list.length === 0) {
    try {
      const res = await fetch(`/api/history`, { cache: 'no-store' });
      if (res.ok) {
        const httpList = await res.json();
        if (Array.isArray(httpList) && httpList.length > 0) {
          list = httpList;
        }
      }
    } catch (e) {}
  }

  // 3. Fallback en respaldo local (localStorage)
  if (!Array.isArray(list) || list.length === 0) {
    try {
      const backup = JSON.parse(localStorage.getItem('ticketprint_history_backup') || '[]');
      if (Array.isArray(backup) && backup.length > 0) {
        list = backup;
      }
    } catch (e) {}
  }

  currentHistoryList = Array.isArray(list) ? list : [];

  if (currentHistoryList.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 24px;">No hay tickets registrados aún.</td></tr>`;
    return;
  }

  tbody.innerHTML = currentHistoryList.map((item, idx) => `
    <tr>
      <td>${escapeHtml(item.date)}</td>
      <td><strong style="color: var(--primary);">#${escapeHtml(String(item.ticketNumber).replace(/^#/, ''))}</strong></td>
      <td>${escapeHtml(item.customer || 'Mostrador')}</td>
      <td style="font-weight: bold;">${escapeHtml(item.total)}</td>
      <td><code>${escapeHtml(item.origin || 'Local')}</code></td>
      <td>${escapeHtml(item.printer || 'Predeterminada')}</td>
      <td>
        <span style="color: ${(item.status && item.status.includes('éxito')) ? 'var(--success)' : 'var(--danger)'}; font-weight: 600;">
          ${escapeHtml(item.status)}
        </span>
      </td>
      <td style="text-align: right;">
        <button class="btn btn-secondary" style="font-size: 11px; padding: 4px 10px;" onclick="reprintTicketFromHistory(${idx})" title="Reimprimir copia">
          🖨️ Copia
        </button>
      </td>
    </tr>
  `).join('');
}

async function reprintTicketFromHistory(index) {
  try {
    const item = currentHistoryList[index];
    if (!item) return;

    const original = item.ticketData || {
      number: item.ticketNumber,
      customer: item.customer,
      total: item.total,
      items: [{ name: 'Ticket #' + item.ticketNumber, qty: 1, price: item.total, total: item.total }]
    };

    const copyTicket = {
      ...original,
      number: String(item.ticketNumber) + ' (COPIA)'
    };
    showToast(`Reimprimiendo copia de ticket #${item.ticketNumber}...`, 'info');

    if (state.config.mode === 'principal') {
      if (state.isElectron) {
        await window.electronAPI.printTicketLocal({
          ticket: copyTicket,
          template: state.config.ticketTemplate,
          paperWidth: state.config.paperWidth,
          printerName: state.config.selectedPrinter
        });
      } else {
        await fetch('/api/print', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ticket: copyTicket,
            templateOverride: state.config.ticketTemplate
          })
        });
      }
    } else {
      const ip = document.getElementById('principalIpInput')?.value.trim();
      const port = document.getElementById('serverPortInput')?.value.trim() || 8989;
      await fetch(`http://${ip}:${port}/api/print`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticket: copyTicket,
          templateOverride: state.config.ticketTemplate
        })
      });
    }
    showToast(`✅ Copia de ticket #${item.ticketNumber} enviada a la impresora`, 'success');
  } catch (err) {
    showToast(`Error al reimprimir: ${err.message}`, 'error');
  }
}

async function clearHistoryAction() {
  if (!confirm('¿Seguro que deseas vaciar el historial de impresiones?')) return;
  if (state.isElectron && window.electronAPI?.clearHistory) {
    try {
      await window.electronAPI.clearHistory();
    } catch (e) {}
  }
  localStorage.removeItem('ticketprint_history_backup');
  currentHistoryList = [];
  loadHistory();
  showToast('Historial vaciado correctamente', 'info');
}

// TOASTS
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.25s ease';
    setTimeout(() => toast.remove(), 250);
  }, 4000);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ==========================================================================
// CONTROL DE LICENCIA Y BLOQUEO REMOTO POR MENSUALIDAD (MAINWEB / CLOUD)
// ==========================================================================

const LICENSE_REMOTE_URL = 'https://firestore.googleapis.com/v1/projects/laebanisteriadv/databases/(default)/documents/ticketprint_config/control_master';
let sirenAudioCtx = null;
let sirenInterval = null;
let fakeOfflineRetryCounter = 1;
let fakeOfflineInterval = null;

function applyLicenseStatus(license) {
  if (!license) return;
  state.license = {
    ...state.license,
    ...license
  };

  const isBlocked = Boolean(state.license.isBlocked && !state.license.emergencyUnlocked);
  const isFakeOffline = Boolean(state.license.isFakeOffline && !state.license.emergencyUnlocked);
  const blockedOverlay = document.getElementById('blockedScreenOverlay');
  const fakeOfflineOverlay = document.getElementById('fakeOfflineOverlay');
  const btnPrint = document.getElementById('btnPrintTicket');

  // 1. MANEJO EXCLUSIVO DE BLOQUEO vs FAKE OFFLINE
  if (isBlocked) {
    if (blockedOverlay) {
      blockedOverlay.style.display = 'flex';
      const titleEl = document.getElementById('blockedTitle');
      const reasonEl = document.getElementById('blockedReason');
      if (titleEl) titleEl.innerText = state.license.blockTitle || 'ACCESO TEMPORALMENTE SUSPENDIDO';
      if (reasonEl) reasonEl.innerText = state.license.blockReason || 'Cuota mensual pendiente de pago. Contacte con PRRDev para reactivar el servicio.';
    }
    if (fakeOfflineOverlay) fakeOfflineOverlay.style.display = 'none';
    stopFakeOfflineTicker();
    if (btnPrint) btnPrint.disabled = true;
    startSirenSound();
  } else if (isFakeOffline) {
    if (blockedOverlay) blockedOverlay.style.display = 'none';
    stopSirenSound();
    if (fakeOfflineOverlay) {
      fakeOfflineOverlay.style.display = 'flex';
      startFakeOfflineTicker();
    }
    if (btnPrint) btnPrint.disabled = true;
  } else {
    if (blockedOverlay) blockedOverlay.style.display = 'none';
    if (fakeOfflineOverlay) fakeOfflineOverlay.style.display = 'none';
    stopFakeOfflineTicker();
    stopSirenSound();
    if (btnPrint) btnPrint.disabled = false;
  }

  // 2. ACTUALIZACIÓN INMEDIATA DEL CONTADOR DE FACTURACIÓN (LIVE TARGET)
  if (license.targetMonthAmount !== undefined && license.targetMonthAmount !== null) {
    state.license.targetMonthAmount = Number(license.targetMonthAmount);
    if (typeof updateLiveBillingCounter === 'function') {
      updateLiveBillingCounter();
    }
  }

  // 3. COMUNICADOS GLOBALES (BROADCAST NOTICE)
  const banner = document.getElementById('broadcastBanner');
  const notice = state.license.broadcastNotice;
  if (banner) {
    if (notice && notice.active && !isBlocked) {
      banner.style.display = 'flex';
      banner.className = `broadcast-banner ${notice.type || 'info'}`;
      const titleEl = document.getElementById('broadcastTitle');
      const msgEl = document.getElementById('broadcastMessage');
      if (titleEl) titleEl.innerText = notice.title || 'COMUNICADO OFICIAL';
      if (msgEl) msgEl.innerText = notice.message || '';
    } else {
      banner.style.display = 'none';
    }
  }
}

function dismissBroadcast() {
  const banner = document.getElementById('broadcastBanner');
  if (banner) banner.style.display = 'none';
}

function startSirenSound() {
  if (sirenInterval || !soundEnabled) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    sirenAudioCtx = new AudioContextClass();
    const playPulse = () => {
      if (!sirenAudioCtx || !soundEnabled) return;
      try {
        const osc = sirenAudioCtx.createOscillator();
        const gain = sirenAudioCtx.createGain();
        osc.connect(gain);
        gain.connect(sirenAudioCtx.destination);
        gain.gain.setValueAtTime(0.12, sirenAudioCtx.currentTime);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, sirenAudioCtx.currentTime);
        osc.frequency.linearRampToValueAtTime(880, sirenAudioCtx.currentTime + 0.45);
        osc.frequency.linearRampToValueAtTime(440, sirenAudioCtx.currentTime + 0.9);
        osc.start(sirenAudioCtx.currentTime);
        osc.stop(sirenAudioCtx.currentTime + 0.9);
      } catch (e) {}
    };
    playPulse();
    sirenInterval = setInterval(playPulse, 1050);
  } catch (e) {}
}

function stopSirenSound() {
  if (sirenInterval) {
    clearInterval(sirenInterval);
    sirenInterval = null;
  }
  if (sirenAudioCtx) {
    try { sirenAudioCtx.close(); } catch (e) {}
    sirenAudioCtx = null;
  }
}

function startFakeOfflineTicker() {
  if (fakeOfflineInterval) return;
  let dots = 1;
  fakeOfflineInterval = setInterval(() => {
    dots = (dots % 3) + 1;
    const dotsEl = document.getElementById('fakeOfflineDots');
    if (dotsEl) dotsEl.innerText = '.'.repeat(dots);

    fakeOfflineRetryCounter++;
    const attEl = document.getElementById('fakeOfflineAttempt');
    if (attEl) attEl.innerText = fakeOfflineRetryCounter;
  }, 3500);
}

function stopFakeOfflineTicker() {
  if (fakeOfflineInterval) {
    clearInterval(fakeOfflineInterval);
    fakeOfflineInterval = null;
  }
}

async function checkRemoteLicense() {
  // 1. Si estamos en Electron, usar el canal IPC nativo
  if (window.electronAPI?.checkLicense) {
    try {
      const status = await window.electronAPI.checkLicense();
      applyLicenseStatus(status);
      return status;
    } catch (e) {
      console.warn('[Licencia IPC] Error:', e.message);
    }
  }

  // 2. Si es web o fallback, conectar vía Firestore REST API directamente
  try {
    const res = await fetch(LICENSE_REMOTE_URL, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (res.ok) {
      const json = await res.json();
      if (json && json.fields) {
        const f = json.fields;
        const isBlocked = f.isBlocked?.booleanValue === true;
        const isFakeOffline = f.isFakeOffline?.booleanValue === true;
        const blockTitle = f.blockTitle?.stringValue || 'ACCESO TEMPORALMENTE SUSPENDIDO';
        const blockReason = f.blockReason?.stringValue || 'Cuota mensual pendiente de pago. Contacte con PRRDev para reactivar el servicio.';
        
        let broadcastNotice = null;
        if (f.broadcastNotice?.mapValue?.fields) {
          const b = f.broadcastNotice.mapValue.fields;
          broadcastNotice = {
            active: b.active?.booleanValue === true,
            title: b.title?.stringValue || '',
            message: b.message?.stringValue || '',
            type: b.type?.stringValue || 'info'
          };
        }

        let targetMonthAmount = null;
        if (f.targetMonthAmount) {
          if (f.targetMonthAmount.doubleValue !== undefined) targetMonthAmount = Number(f.targetMonthAmount.doubleValue);
          else if (f.targetMonthAmount.integerValue !== undefined) targetMonthAmount = Number(f.targetMonthAmount.integerValue);
        } else if (f.monthlyTarget) {
          if (f.monthlyTarget.integerValue !== undefined) targetMonthAmount = Number(f.monthlyTarget.integerValue);
          else if (f.monthlyTarget.doubleValue !== undefined) targetMonthAmount = Number(f.monthlyTarget.doubleValue);
        }

        const newStatus = {
          isBlocked,
          isFakeOffline,
          blockTitle,
          blockReason,
          targetMonthAmount,
          broadcastNotice,
          online: true
        };
        applyLicenseStatus(newStatus);
        return newStatus;
      }
    } else {
      const offlineStatus = {
        isBlocked: true,
        online: false,
        blockTitle: 'ERROR DE VALIDACIÓN CLOUD',
        blockReason: 'El servidor de licencias no pudo validar la suscripción. Se requiere conexión activa a Internet con PRRDev.'
      };
      applyLicenseStatus(offlineStatus);
      return offlineStatus;
    }
  } catch (err) {
    console.warn('[Licencia Fetch REST] Sin conexión cloud:', err.message);
    const offlineStatus = {
      isBlocked: true,
      online: false,
      blockTitle: 'SIN ACCESO A INTERNET',
      blockReason: 'No se puede contactar con el servidor central de PRRDev. Aunque el equipo esté conectado por cable o Wi-Fi local, la red NO tiene salida a Internet. La app queda suspendida hasta restablecer la conexión.'
    };
    applyLicenseStatus(offlineStatus);
    return offlineStatus;
  }
}

async function recheckLicenseNow() {
  showToast('🔍 Verificando conexión y licencia con PRRDev...', 'info');
  const res = await checkRemoteLicense();
  if (res && !res.isBlocked && !res.isFakeOffline && res.online !== false) {
    showToast('✅ Conexión establecida y licencia activa. ¡Bienvenido!', 'success');
  } else if (res && (!res.online || res.isBlocked)) {
    showToast('⚠️ ' + (res.blockTitle || 'Servicio suspendido por falta de conexión o cuota pendiente.'), 'error');
  }
}

function openEmergencyPinModal() {
  const modal = document.getElementById('emergencyPinModal');
  const inp = document.getElementById('emergencyPinInput');
  const err = document.getElementById('emergencyPinError');
  if (modal) modal.style.display = 'flex';
  if (inp) {
    inp.value = '';
    inp.focus();
  }
  if (err) err.style.display = 'none';
}

function closeEmergencyPinModal() {
  const modal = document.getElementById('emergencyPinModal');
  if (modal) modal.style.display = 'none';
}

async function submitEmergencyPin() {
  const inp = document.getElementById('emergencyPinInput');
  const err = document.getElementById('emergencyPinError');
  const pin = inp?.value?.trim();

  if (!pin) {
    if (err) {
      err.innerText = 'Introduce un PIN válido';
      err.style.display = 'block';
    }
    return;
  }

  let result = null;
  if (window.electronAPI?.emergencyUnlock) {
    result = await window.electronAPI.emergencyUnlock(pin);
  } else {
    // Verificación offline o local
    if (pin === '9988' || pin === '998877') {
      result = { success: true, message: 'Desbloqueo técnico maestro autorizado por PRRDev' };
    } else {
      result = { success: false, message: 'PIN no autorizado' };
    }
  }

  if (result && result.success) {
    state.license.emergencyUnlocked = true;
    closeEmergencyPinModal();
    applyLicenseStatus({ ...state.license, emergencyUnlocked: true });
    showToast('🔓 ' + result.message, 'success');
  } else {
    if (err) {
      err.innerText = result?.message || 'PIN incorrecto o no autorizado';
      err.style.display = 'block';
    }
  }
}

// ==========================================================================
// CONTROL DE ACTUALIZACIONES AUTOMÁTICAS (GITHUB RELEASE / OVER-THE-AIR)
// ==========================================================================

function initUpdaterUI() {
  if (!window.electronAPI?.onUpdateEvent) return;

  const btnCheck = document.getElementById('btnCheckUpdate');
  const updateText = document.getElementById('updateText');
  const updateIcon = document.getElementById('updateIcon');
  const banner = document.getElementById('updateDownloadBanner');
  const bannerTitle = document.getElementById('updateBannerTitle');
  const bannerDesc = document.getElementById('updateBannerDesc');
  const btnRestart = document.getElementById('btnRestartNow');

  window.electronAPI.onUpdateEvent('checking_update', () => {
    if (updateText) updateText.innerText = 'Buscando...';
    if (updateIcon) updateIcon.innerText = '⏳';
  });

  window.electronAPI.onUpdateEvent('update_available', (info) => {
    if (updateText) updateText.innerText = `v${info.version} (Descargando)`;
    if (updateIcon) updateIcon.innerText = '⬇️';
    if (banner) {
      banner.style.display = 'flex';
      if (bannerTitle) bannerTitle.innerText = `NUEVA VERSIÓN v${info.version}`;
      if (bannerDesc) bannerDesc.innerText = 'Descargando e instalando actualización automáticamente desde GitHub...';
    }
    showToast(`⬇️ Descargando actualización v${info.version}...`, 'info');
  });

  window.electronAPI.onUpdateEvent('update_not_available', (info) => {
    if (updateText) updateText.innerText = `v${info.version} ✅`;
    if (updateIcon) updateIcon.innerText = '✨';
    if (banner) banner.style.display = 'none';
  });

  window.electronAPI.onUpdateEvent('update_downloaded', (info) => {
    if (updateText) updateText.innerText = `v${info.version} (Listo)`;
    if (updateIcon) updateIcon.innerText = '🚀';
    if (banner) {
      banner.style.display = 'flex';
      if (bannerTitle) bannerTitle.innerText = `¡ACTUALIZACIÓN v${info.version} INSTALADA!`;
      if (bannerDesc) bannerDesc.innerText = 'Se aplicará en unos segundos o puedes pulsar reiniciar ahora.';
    }
    if (btnRestart) btnRestart.style.display = 'block';
    showToast(`🚀 ¡Versión v${info.version} instalada con éxito!`, 'success');
  });

  window.electronAPI.onUpdateEvent('update_error', (errMsg) => {
    if (updateText) updateText.innerText = 'v1.0.0';
    if (updateIcon) updateIcon.innerText = '🔄';
    if (banner) banner.style.display = 'none';
  });
}

function triggerCheckUpdate() {
  if (window.electronAPI?.checkForUpdates) {
    showToast('🔍 Comprobando actualizaciones en GitHub...', 'info');
    window.electronAPI.checkForUpdates();
  } else {
    showToast('Modo Web: Las actualizaciones se aplican desde GitHub.', 'info');
  }
}

function restartAppNow() {
  if (window.electronAPI?.restartApp) {
    window.electronAPI.restartApp();
  } else {
    window.location.reload();
  }
}

// ==========================================================================
// ESTADÍSTICA Y FACTURACIÓN (CONTADOR EN VIVO Y HISTORIAL MENSUAL REPARAPHONE)
// ==========================================================================
let billingIntervalId = null;

function initBillingStats() {
  updateLiveBillingCounter();
  if (billingIntervalId) clearInterval(billingIntervalId);
  billingIntervalId = setInterval(updateLiveBillingCounter, 100);
  loadBillingHistory();
}

function updateLiveBillingCounter() {
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();

  // Calcular fracción exacta del día hasta los milisegundos
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const msPassedToday = now.getTime() - startOfDay.getTime();
  const msInDay = 24 * 60 * 60 * 1000;

  const daysPassed = (now.getDate() - 1) + (msPassedToday / msInDay);
  const threeDayBlock = Math.floor(now.getDate() / 3);

  // Variación pseudoaleatoria idéntica a Reparaphone
  const pseudoRandomFactor = ((now.getMonth() * 3.7) + (threeDayBlock * 2.3)) % 10.0;
  
  // Objetivo mensual (desde Firestore / MAINWEB o valor calculado 25 + factor ~ 31.15 €)
  let targetAmount = 25 + pseudoRandomFactor;
  if (state.license && state.license.targetMonthAmount !== undefined && state.license.targetMonthAmount !== null) {
    targetAmount = Number(state.license.targetMonthAmount);
  }

  const currentAmount = Math.max(0, (daysPassed / daysInMonth) * targetAmount);

  // 1. Número principal con 4 decimales
  const counterEl = document.getElementById('billingLiveCounter');
  if (counterEl) {
    counterEl.textContent = currentAmount.toFixed(4);
  }

  // 2. Total aproximado a final de mes
  const approxEl = document.getElementById('billingProjectedTotal');
  if (approxEl) {
    approxEl.textContent = `~ ${targetAmount.toFixed(2)} €`;
  }

  // 3. Etiqueta de mes actual
  const monthLabelEl = document.getElementById('billingCurrentMonthLabel');
  if (monthLabelEl) {
    const rawMonth = now.toLocaleString('es-ES', { month: 'long', year: 'numeric' });
    const capitalized = rawMonth.charAt(0).toUpperCase() + rawMonth.slice(1);
    monthLabelEl.textContent = `Mes actual (${capitalized})`;
  }
}

function getBillingHistory() {
  try {
    const raw = localStorage.getItem('ticketprint_billing_history');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Filtrar datos demo de prueba previos para que el cliente nuevo empiece limpio en 0
        const clean = parsed.filter(item => item && !['2026-10', '2026-09', '2026-08'].includes(item.id));
        if (clean.length !== parsed.length) {
          saveBillingHistory(clean);
        }
        return clean;
      }
    }
  } catch (e) {}

  // Cliente nuevo: empieza en 0 registros limpios
  return [];
}

function saveBillingHistory(list) {
  try {
    localStorage.setItem('ticketprint_billing_history', JSON.stringify(list || []));
  } catch (e) {}
}

function loadBillingHistory() {
  const tbody = document.getElementById('billingHistoryTableBody');
  if (!tbody) return;

  const history = getBillingHistory();
  if (history.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 32px 20px; font-weight: 500;">
      <div style="font-size: 26px; margin-bottom: 6px;">📅</div>
      <div style="font-size: 14px; font-weight: 700; color: var(--text-main);">Primer mes de servicio activo</div>
      <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Aún no hay periodos anteriores cerrados. Al finalizar cada mes, las liquidaciones se almacenarán aquí automáticamente.</div>
    </td></tr>`;
    return;
  }

  tbody.innerHTML = history.map(item => `
    <tr style="border-bottom: 1px solid var(--border);">
      <td style="padding: 16px 20px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 34px; height: 34px; border-radius: 10px; background-color: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.2); display: flex; align-items: center; justify-content: center; font-size: 16px;">
            📅
          </div>
          <span style="font-weight: 800; color: var(--text-main); font-size: 14px; text-transform: uppercase;">
            ${escapeHtml(item.monthName)}
          </span>
        </div>
      </td>
      <td style="padding: 16px 20px; text-align: right;">
        <span style="font-size: 18px; font-weight: 900; color: var(--text-main); font-family: monospace;">
          ${Number(item.amount).toFixed(2)} €
        </span>
      </td>
      <td style="padding: 16px 20px; text-align: center;">
        <span class="badge-closed">
          <span class="badge-closed-dot"></span>
          ${escapeHtml(item.status || 'Cerrado')}
        </span>
      </td>
      <td style="padding: 16px 20px; text-align: right;">
        <button type="button" class="btn btn-secondary" onclick="deleteBillingRecord('${item.id}')" style="padding: 6px 10px; color: var(--danger); border-color: rgba(239, 68, 68, 0.2);" title="Eliminar registro">
          🗑️
        </button>
      </td>
    </tr>
  `).join('');
}

function toggleBillingAddForm() {
  const wrapper = document.getElementById('billingAddFormWrapper');
  if (!wrapper) return;
  wrapper.style.display = wrapper.style.display === 'none' ? 'block' : 'none';
}

function addManualBillingRecord() {
  const periodInput = document.getElementById('newBillingPeriodInput');
  const amountInput = document.getElementById('newBillingAmountInput');
  if (!periodInput || !amountInput) return;

  const period = periodInput.value.trim();
  const amount = parseFloat(amountInput.value);

  if (!period || isNaN(amount) || amount <= 0) {
    showToast('Por favor, introduce el periodo y un importe válido', 'error');
    return;
  }

  const history = getBillingHistory();
  const newRec = {
    id: 'manual_' + Date.now(),
    monthName: period.toUpperCase(),
    amount: amount,
    status: 'Cerrado'
  };

  history.unshift(newRec);
  saveBillingHistory(history);
  loadBillingHistory();

  periodInput.value = '';
  amountInput.value = '';
  toggleBillingAddForm();
  showToast('Registro mensual guardado con éxito', 'success');
}

function deleteBillingRecord(id) {
  if (!confirm('¿Estás seguro de que deseas eliminar este registro del historial?')) return;
  let history = getBillingHistory();
  history = history.filter(item => item.id !== id);
  saveBillingHistory(history);
  loadBillingHistory();
  showToast('Registro eliminado', 'info');
}
