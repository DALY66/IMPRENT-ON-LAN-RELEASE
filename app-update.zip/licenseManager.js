const https = require('https');

const FIRESTORE_ENDPOINT = 'https://firestore.googleapis.com/v1/projects/laebanisteriadv/databases/(default)/documents/ticketprint_config/control_master';
const USERS_ENDPOINT = 'https://firestore.googleapis.com/v1/projects/laebanisteriadv/databases/(default)/documents/ticketprint_users';

let currentState = {
  isBlocked: false,
  isFakeOffline: false,
  blockTitle: 'CONEXIÓN A INTERNET OBLIGATORIA',
  blockReason: 'La aplicación requiere conexión activa a Internet para validar la suscripción con PRRDev.',
  broadcastNotice: null,
  emergencyUnlocked: false,
  lastChecked: null,
  online: false,
  hasValidatedOnce: false,
  targetMonthAmount: null
};

let checkIntervalId = null;
const listeners = [];

function addListener(fn) {
  listeners.push(fn);
}

function notifyListeners() {
  listeners.forEach(fn => {
    try { fn(currentState); } catch (e) { console.error('Error en listener de licencia:', e); }
  });
}

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const options = {
      hostname: parsed.hostname,
      path: parsed.pathname + (parsed.search || ''),
      method: 'GET',
      headers: {
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Accept': 'application/json'
      },
      timeout: 6000
    };

    const req = https.request(options, (res) => {
      let raw = '';
      res.on('data', chunk => raw += chunk);
      res.on('end', () => {
        try {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(JSON.parse(raw));
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${raw}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timeout de conexión'));
    });

    req.on('error', (err) => reject(err));
    req.end();
  });
}

async function checkLicense() {
  try {
    const doc = await fetchJson(FIRESTORE_ENDPOINT);
    if (doc && doc.fields) {
      const f = doc.fields;
      const isBlocked = f.isBlocked?.booleanValue === true;
      const isFakeOffline = f.isFakeOffline?.booleanValue === true;
      const blockTitle = f.blockTitle?.stringValue || 'ACCESO TEMPORALMENTE SUSPENDIDO';
      const blockReason = f.blockReason?.stringValue || 'Cuota mensual pendiente de pago. Contacte con PRRDev para reactivar el servicio.';
      
      let broadcastNotice = null;
      if (f.broadcastNotice?.mapValue?.fields) {
        const b = f.broadcastNotice.mapValue.fields;
        broadcastNotice = {
          active: b.active?.booleanValue === true,
          title: b.title?.stringValue || '',
          message: b.message?.stringValue || '',
          type: b.type?.stringValue || 'info'
        };
      }

      let targetMonthAmount = null;
      if (f.targetMonthAmount) {
        if (f.targetMonthAmount.doubleValue !== undefined) targetMonthAmount = Number(f.targetMonthAmount.doubleValue);
        else if (f.targetMonthAmount.integerValue !== undefined) targetMonthAmount = Number(f.targetMonthAmount.integerValue);
      } else if (f.monthlyTarget) {
        if (f.monthlyTarget.integerValue !== undefined) targetMonthAmount = Number(f.monthlyTarget.integerValue);
        else if (f.monthlyTarget.doubleValue !== undefined) targetMonthAmount = Number(f.monthlyTarget.doubleValue);
      }

      currentState.isBlocked = isBlocked;
      currentState.isFakeOffline = isFakeOffline;
      currentState.blockTitle = blockTitle;
      currentState.blockReason = blockReason;
      currentState.broadcastNotice = broadcastNotice;
      currentState.targetMonthAmount = targetMonthAmount;
      currentState.lastChecked = new Date().toISOString();
      currentState.online = true;
      currentState.hasValidatedOnce = true;

      // Si en la nube se desbloquea, quitar desbloqueo de emergencia temporal
      if (!isBlocked && currentState.emergencyUnlocked) {
        currentState.emergencyUnlocked = false;
      }

      notifyListeners();
      return currentState;
    }
  } catch (err) {
    // Si falla la conexión a Internet o el router no tiene acceso externo:
    currentState.online = false;
    currentState.isBlocked = true;
    currentState.blockTitle = 'SIN ACCESO A INTERNET';
    currentState.blockReason = 'No se ha podido contactar con el servidor central de PRRDev. Aunque el equipo esté conectado por cable o Wi-Fi local, la red NO tiene salida a Internet. Para garantizar la seguridad del servicio y la vigencia de la suscripción, la app queda suspendida hasta restablecer la conexión.';
    console.warn('[Licencia Cloud] Sin salida a Internet:', err.message);
    notifyListeners();
  }
  return currentState;
}

async function verifyEmergencyPin(pin) {
  if (!pin) return { success: false, message: 'Introduce un código PIN' };

  // 1. PIN Maestro de emergencia de PRRDev
  if (pin.trim() === '9988' || pin.trim() === '998877') {
    currentState.emergencyUnlocked = true;
    notifyListeners();
    return { success: true, message: 'Desbloqueo técnico maestro autorizado por PRRDev' };
  }

  // 2. Verificar en ticketprint_users en Firestore si hay conexión
  try {
    const usersData = await fetchJson(USERS_ENDPOINT);
    if (usersData && usersData.documents) {
      const found = usersData.documents.find(doc => {
        const p = doc.fields?.pin?.stringValue;
        const role = doc.fields?.role?.stringValue;
        return p === pin.trim() && (role === 'Administrador' || role === 'Admin');
      });
      if (found) {
        currentState.emergencyUnlocked = true;
        notifyListeners();
        return { success: true, message: 'Desbloqueo de Administrador autorizado' };
      }
    }
  } catch (err) {
    console.warn('[Licencia PIN] Error al validar PIN remoto:', err.message);
  }

  return { success: false, message: 'PIN no autorizado o incorrecto' };
}

function startLicenseMonitor(intervalMs = 2500) {
  if (checkIntervalId) clearInterval(checkIntervalId);
  // Chequeo inicial
  checkLicense();
  // Chequeo periódico cada X segundos (2.5s para respuesta instantánea)
  checkIntervalId = setInterval(checkLicense, intervalMs);
}

function stopLicenseMonitor() {
  if (checkIntervalId) {
    clearInterval(checkIntervalId);
    checkIntervalId = null;
  }
}

function getStatus() {
  const isEffectiveBlocked = (currentState.isBlocked || !currentState.online) && !currentState.emergencyUnlocked;
  return {
    ...currentState,
    isBlocked: isEffectiveBlocked,
    isFakeOffline: Boolean(currentState.isFakeOffline && !currentState.emergencyUnlocked),
    blockTitle: (!currentState.online && !currentState.emergencyUnlocked) ? (currentState.blockTitle || 'SIN ACCESO A INTERNET') : currentState.blockTitle,
    blockReason: (!currentState.online && !currentState.emergencyUnlocked) ? (currentState.blockReason || 'Se requiere conexión a Internet activa para validar la suscripción con PRRDev.') : currentState.blockReason
  };
}

module.exports = {
  checkLicense,
  getStatus,
  verifyEmergencyPin,
  startLicenseMonitor,
  stopLicenseMonitor,
  addListener
};
