const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const configManager = require('./configManager');
const printerService = require('./printerService');
const networkUtils = require('./networkUtils');
const server = require('./server');
const licenseManager = require('./licenseManager');
const updaterService = require('./updaterService');
const historyManager = require('./historyManager');

let mainWindow = null;

function printHtml({ html, printerName, paperWidth }) {
  return new Promise((resolve, reject) => {
    // Ventana oculta para renderizar el ticket térmico con precisión milimétrica
    const printWindow = new BrowserWindow({
      show: false,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true
      }
    });

    const is58 = paperWidth === '58mm';
    // Codificar en Base64 o data URI para cargar el HTML instantáneamente
    printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);

    printWindow.webContents.on('did-finish-load', () => {
      // 80mm = ~80000 micras, 58mm = ~58000 micras
      const printOptions = {
        silent: true,
        printBackground: true,
        deviceName: printerName,
        margins: {
          marginType: 'none'
        },
        pageSize: is58
          ? { width: 58000, height: 297000 }
          : { width: 80000, height: 297000 }
      };

      printWindow.webContents.print(printOptions, (success, failureReason) => {
        printWindow.close();
        if (!success) {
          reject(new Error(failureReason || 'Error al imprimir en Windows'));
        } else {
          resolve({ success: true });
        }
      });
    });

    printWindow.webContents.on('did-fail-load', (e, errCode, errDesc) => {
      printWindow.close();
      reject(new Error(`Fallo al cargar ticket: ${errDesc}`));
    });
  });
}

function updateServerState(config) {
  if (config.mode === 'principal') {
    server.registerPrintHandler(printHtml);
    server.startServer(config.serverPort || 8989);
  } else {
    server.stopServer();
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 860,
    minWidth: 980,
    minHeight: 700,
    title: 'Imprent on LAN',
    icon: path.join(__dirname, 'public', 'assets', 'network_printer_icon.ico'),
    autoHideMenuBar: true,
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: '#070b14',
      symbolColor: '#cbd5e1',
      height: 38
    },
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  const config = configManager.loadConfig();
  updateServerState(config);

  mainWindow.loadFile(path.join(__dirname, 'public', 'index.html'));

  // Permitir recargar con F5 o Ctrl+R
  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F5' || (input.control && input.key.toLowerCase() === 'r')) {
      mainWindow.reload();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Configuración de IPC handlers
ipcMain.handle('get-config', async () => {
  return configManager.loadConfig();
});

ipcMain.handle('save-config', async (event, newConfig) => {
  const current = configManager.loadConfig();
  const updated = { ...current, ...newConfig };
  const res = configManager.saveConfig(updated);
  if (res.success) {
    updateServerState(updated);
  }
  return res;
});

ipcMain.handle('get-printers', async () => {
  try {
    // En Electron podemos usar webContents.getPrintersAsync() si está disponible
    if (mainWindow && mainWindow.webContents.getPrintersAsync) {
      try {
        const electronPrinters = await mainWindow.webContents.getPrintersAsync();
        if (electronPrinters && electronPrinters.length > 0) {
          return electronPrinters.map(p => ({
            name: p.name,
            isDefault: p.isDefault,
            status: p.status === 0 ? 'Disponible' : 'Listo',
            port: ''
          }));
        }
      } catch (e) {
        console.warn('Fallback a PowerShell para impresoras:', e.message);
      }
    }
    return await printerService.getSystemPrinters();
  } catch (err) {
    console.error('Error al listar impresoras:', err);
    return [];
  }
});

ipcMain.handle('get-local-ips', async () => {
  return networkUtils.getLocalIps();
});

ipcMain.handle('discover-principal', async () => {
  const config = configManager.loadConfig();
  return await networkUtils.discoverPrincipal(config.discoveryPort || 8990, 2500);
});

ipcMain.handle('print-ticket-local', async (event, { ticket, template, business, paperWidth, printerName }) => {
  const license = licenseManager.getStatus();
  if (license.isBlocked && !license.emergencyUnlocked) {
    throw new Error(`Acceso suspendido: ${license.blockReason || 'Cuota mensual pendiente de pago. Contacte con PRRDev.'}`);
  }
  const tpl = template || { fields: { businessName: { value: business?.name || '' } } };
  const ticketHtml = printerService.generateTicketHtml(ticket, tpl, paperWidth);
  const result = await printHtml({ html: ticketHtml, printerName, paperWidth });

  // Guardar en el historial de tickets local persistente
  try {
    historyManager.addEntry({
      ticketNumber: ticket.number !== undefined ? String(ticket.number) : '0',
      date: new Date().toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }),
      customer: ticket.customer || 'Mostrador',
      total: ticket.total !== undefined ? (typeof ticket.total === 'number' ? ticket.total.toFixed(2) + '€' : ticket.total) : '0.00€',
      origin: 'Local (Este PC)',
      printer: printerName || 'Impresora Local',
      status: 'Impreso con éxito',
      ticketData: ticket
    });
  } catch (err) {
    console.error('Error registrando ticket en historial:', err.message);
  }

  return result;
});

// Handlers de Historial de Impresiones
ipcMain.handle('get-history', async () => {
  return historyManager.getHistory(150);
});

ipcMain.handle('clear-history', async () => {
  return historyManager.clearHistory();
});

// Handler para difundir plantilla y diseño a la red LAN
ipcMain.handle('broadcast-template', async (event, { ticketTemplate, appTheme }) => {
  try {
    const cfg = configManager.loadConfig();
    if (ticketTemplate) cfg.ticketTemplate = ticketTemplate;
    if (appTheme) cfg.appTheme = appTheme;
    configManager.saveConfig(cfg);

    const count = server.broadcastToClients('template_synced', {
      ticketTemplate: cfg.ticketTemplate,
      appTheme: cfg.appTheme,
      paperWidth: cfg.paperWidth || '80mm',
      syncedAt: new Date().toLocaleTimeString('es-ES')
    });

    return {
      success: true,
      message: `Diseño y configuración emitidos con éxito a ${count} equipo(s) en la red`,
      clientsCount: count
    };
  } catch (err) {
    return {
      success: false,
      error: err.message
    };
  }
});

// Handlers de Control Remoto de Licencia (MAINWEB)
ipcMain.handle('get-license-status', async () => {
  return licenseManager.getStatus();
});

ipcMain.handle('check-license', async () => {
  return await licenseManager.checkLicense();
});

ipcMain.handle('emergency-unlock', async (event, pin) => {
  return await licenseManager.verifyEmergencyPin(pin);
});

// Handlers de Actualizaciones Automáticas de GitHub
ipcMain.on('check_for_updates', () => {
  updaterService.checkForUpdates(mainWindow);
});

ipcMain.on('restart_app', () => {
  updaterService.restartApp();
});

ipcMain.handle('get-update-state', () => {
  return updaterService.getUpdateState();
});

app.whenReady().then(() => {
  createWindow();

  // Iniciar comprobador de actualizaciones desde GitHub
  updaterService.initUpdater(mainWindow);

  // Iniciar monitor de verificación de cuota / mensualidad con MAINWEB (cada 2.5s para respuesta instantánea)
  licenseManager.startLicenseMonitor(2500);
  licenseManager.addListener((status) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('license-status-changed', status);
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  server.stopServer();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

